import assert from "node:assert/strict";
import path from "node:path";
import { pathToFileURL } from "node:url";

function createResponse() {
  return {
    statusCode: 200,
    headers: {},
    body: undefined,
    setHeader(name, value) { this.headers[name] = value; },
    status(code) { this.statusCode = code; return this; },
    json(value) { this.body = value; return this; },
  };
}

async function load(relativePath) {
  const absolutePath = path.resolve(".serverless-check", relativePath);
  return import(pathToFileURL(absolutePath).href);
}

const previous = {
  GAS_URL: process.env.GAS_URL,
  GAS_BACKEND_SECRET: process.env.GAS_BACKEND_SECRET,
  SESSION_SECRET: process.env.SESSION_SECRET,
};

process.env.GAS_URL = "https://script.google.com/macros/s/AKfycbMULTIROLECHECK/exec";
process.env.GAS_BACKEND_SECRET = "multirole-check-backend-secret";
process.env.SESSION_SECRET = "multirole-check-session-secret-at-least-32-characters";

try {
  const auth = await load("lib/serverless/auth.js");
  const requests = await load("api/requests.js");
  const switchRole = await load("api/auth/switch-role.js");

  const requester = {
    nrk: "1001",
    name: "Pemohon A",
    jobTitle: "Guru",
    appRole: "PEMOHON",
    activeRole: "PEMOHON",
    roles: ["PEMOHON", "PETUGAS_GUDANG"],
    mustChangePin: false,
  };
  const otherRequester = {
    ...requester,
    nrk: "1002",
    name: "Pemohon B",
    roles: ["PEMOHON"],
  };
  const warehouseUser = {
    ...requester,
    appRole: "PETUGAS_GUDANG",
    activeRole: "PETUGAS_GUDANG",
  };

  const cookieFor = (user) => `pb_session=${encodeURIComponent(auth.createSessionToken(user))}`;

  let currentRequest = {
    id: "REQ-1",
    requesterNrk: "1001",
    requesterName: "Pemohon A",
    requesterRole: "Guru",
    itemName: "Kertas",
    quantity: 1,
    unit: "Rim",
    purpose: "Kegiatan belajar",
    requestDate: "2026-07-30",
    status: "PENDING_VALIDATION",
    notes: "",
    handoverPhotoUrl: "",
  };
  let lastUpdate = null;

  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (_url, init) => {
    const body = JSON.parse(init.body);
    if (body.action === "listRequests") {
      return new Response(JSON.stringify({
        success: true,
        data: [currentRequest, { ...currentRequest, id: "REQ-2", requesterNrk: "1002" }],
      }), { status: 200 });
    }
    if (body.action === "updateRequest") {
      lastUpdate = body.data;
      currentRequest = { ...currentRequest, ...body.data };
      return new Response(JSON.stringify({ success: true, message: "ok" }), { status: 200 });
    }
    throw new Error(`Unexpected GAS action: ${body.action}`);
  };

  try {
    let response = createResponse();
    switchRole.default({
      method: "POST",
      headers: { cookie: cookieFor(requester) },
      body: { role: "PETUGAS_GUDANG" },
    }, response);
    assert.equal(response.statusCode, 200);
    assert.equal(response.body?.user?.activeRole, "PETUGAS_GUDANG");
    assert.ok(response.headers["Set-Cookie"]);

    response = createResponse();
    switchRole.default({
      method: "POST",
      headers: { cookie: cookieFor(otherRequester) },
      body: { role: "APPROVER" },
    }, response);
    assert.equal(response.statusCode, 403);

    response = createResponse();
    await requests.default({
      method: "GET",
      headers: { cookie: cookieFor(requester) },
      url: "/api/requests",
    }, response);
    assert.equal(response.statusCode, 200);
    assert.equal(response.body?.data?.length, 1);
    assert.equal(response.body?.data?.[0]?.id, "REQ-1");

    response = createResponse();
    await requests.default({
      method: "POST",
      headers: { cookie: cookieFor(warehouseUser) },
      url: "/api/requests",
      body: {
        action: "workflow",
        id: "REQ-1",
        workflowAction: "handover",
        photoUrl: "data:image/jpeg;base64,AAA",
        notes: "",
      },
    }, response);
    assert.equal(response.statusCode, 200);
    assert.equal(lastUpdate?.status, "AWAITING_REQUESTER_CONFIRMATION");

    response = createResponse();
    await requests.default({
      method: "POST",
      headers: { cookie: cookieFor(requester) },
      url: "/api/requests",
      body: {
        action: "workflow",
        id: "REQ-1",
        workflowAction: "confirm_receipt",
        receiptCondition: "DITERIMA_BAIK",
        notes: "",
        photoUrl: "",
      },
    }, response);
    assert.equal(response.statusCode, 200);
    assert.equal(lastUpdate?.status, "VALIDATED");
    assert.equal(lastUpdate?.requesterConfirmedNrk, "1001");

    currentRequest = {
      ...currentRequest,
      status: "AWAITING_REQUESTER_CONFIRMATION",
      requesterNrk: "1001",
    };
    response = createResponse();
    await requests.default({
      method: "POST",
      headers: { cookie: cookieFor(otherRequester) },
      url: "/api/requests",
      body: {
        action: "workflow",
        id: "REQ-1",
        workflowAction: "confirm_receipt",
        receiptCondition: "DITERIMA_BAIK",
        notes: "",
        photoUrl: "",
      },
    }, response);
    assert.equal(response.statusCode, 403);
  } finally {
    globalThis.fetch = originalFetch;
  }

  console.log("Multi-role + requester confirmation workflow test passed.");
} finally {
  for (const [key, value] of Object.entries(previous)) {
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
}
