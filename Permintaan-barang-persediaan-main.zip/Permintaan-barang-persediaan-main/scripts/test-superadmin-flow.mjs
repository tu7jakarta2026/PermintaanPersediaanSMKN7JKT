import assert from "node:assert/strict";
import path from "node:path";
import { pathToFileURL } from "node:url";

function createResponse() {
  return {
    statusCode: 200,
    headers: {},
    body: undefined,
    setHeader(name, value) { this.headers[name] = value; },
    status(code) { this.statusCode = code; return this; },
    json(value) { this.body = value; return this; },
  };
}

async function load(relativePath) {
  const absolutePath = path.resolve(".serverless-check", relativePath);
  return import(pathToFileURL(absolutePath).href);
}

const previous = {
  GAS_URL: process.env.GAS_URL,
  GAS_BACKEND_SECRET: process.env.GAS_BACKEND_SECRET,
  SESSION_SECRET: process.env.SESSION_SECRET,
};

process.env.GAS_URL = "https://script.google.com/macros/s/AKfycbSUPERADMINCHECK/exec";
process.env.GAS_BACKEND_SECRET = "superadmin-check-backend-secret";
process.env.SESSION_SECRET = "superadmin-check-session-secret-at-least-32-characters";

try {
  const auth = await load("lib/serverless/auth.js");
  const requests = await load("api/requests.js");

  const admin = {
    nrk: "9999",
    name: "Administrator Sistem",
    jobTitle: "Admin",
    appRole: "ADMIN",
    activeRole: "ADMIN",
    roles: ["PEMOHON", "ADMIN"],
    mustChangePin: false,
  };
  const cookie = `pb_session=${encodeURIComponent(auth.createSessionToken(admin))}`;

  let currentRequest = {
    id: "REQ-ADMIN-1",
    requesterNrk: "1001",
    requesterName: "Pemohon Asli",
    requesterRole: "Guru",
    itemName: "Kertas",
    quantity: 1,
    unit: "Rim",
    purpose: "Kegiatan belajar",
    requestDate: "2026-07-30",
    status: "PENDING_RECEIPT",
    notes: "",
    handoverPhotoUrl: "",
  };
  const audits = [];
  const creates = [];

  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (_url, init) => {
    const body = JSON.parse(init.body);
    if (body.action === "listRequests") {
      return new Response(JSON.stringify({ success: true, data: [currentRequest] }), { status: 200 });
    }
    if (body.action === "updateRequest") {
      currentRequest = { ...currentRequest, ...body.data };
      audits.push(body.audit);
      return new Response(JSON.stringify({ success: true, message: "ok" }), { status: 200 });
    }
    if (body.action === "createRequest") {
      creates.push(body.data);
      audits.push(body.audit);
      return new Response(JSON.stringify({ success: true, message: "created" }), { status: 200 });
    }
    throw new Error(`Unexpected GAS action: ${body.action}`);
  };

  const workflow = async (workflowAction, extra = {}) => {
    const response = createResponse();
    await requests.default({
      method: "POST",
      headers: { cookie },
      url: "/api/requests",
      body: { action: "workflow", id: currentRequest.id, workflowAction, notes: "", ...extra },
    }, response);
    assert.equal(response.statusCode, 200, JSON.stringify(response.body));
  };

  try {
    let response = createResponse();
    await requests.default({
      method: "POST",
      headers: { cookie },
      url: "/api/requests",
      body: {
        action: "create",
        data: { itemName: "Toner", quantity: 1, unit: "Pcs", purpose: "Operasional", requestDate: "2026-07-30" },
      },
    }, response);
    assert.equal(response.statusCode, 200);
    assert.equal(creates.length, 1);
    assert.equal(creates[0].requesterNrk, "9999");
    assert.equal(audits[0].isAdminOverride, true);
    assert.equal(audits[0].actedAs, "PEMOHON");

    await workflow("receive");
    assert.equal(currentRequest.status, "PENDING_APPROVAL");
    assert.equal(audits.at(-1).actedAs, "PETUGAS_GUDANG");

    await workflow("approve");
    assert.equal(currentRequest.status, "PENDING_VALIDATION");
    assert.equal(audits.at(-1).actedAs, "APPROVER");

    await workflow("handover", { photoUrl: "data:image/jpeg;base64,AAA" });
    assert.equal(currentRequest.status, "AWAITING_REQUESTER_CONFIRMATION");

    await workflow("confirm_receipt", { receiptCondition: "DITERIMA_BAIK", photoUrl: "" });
    assert.equal(currentRequest.status, "VALIDATED");
    assert.equal(currentRequest.requesterConfirmedNrk, "9999");
    assert.equal(currentRequest.receiptConfirmedRole, "ADMIN");
    assert.equal(audits.at(-1).action, "ADMIN_CONFIRM_RECEIPT");
    assert.equal(audits.at(-1).actedAs, "PEMOHON_OVERRIDE");
    assert.equal(audits.every((audit) => audit.isAdminOverride === true), true);
  } finally {
    globalThis.fetch = originalFetch;
  }

  console.log("Super Admin full workflow + audit test passed.");
} finally {
  for (const [key, value] of Object.entries(previous)) {
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
}
