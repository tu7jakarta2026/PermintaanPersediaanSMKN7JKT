import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
import path from "node:path";

function createResponse() {
  return {
    statusCode: 200,
    headers: {},
    body: undefined,
    setHeader(name, value) { this.headers[name] = value; },
    status(code) { this.statusCode = code; return this; },
    json(value) { this.body = value; return this; },
  };
}

async function load(relativePath) {
  const absolutePath = path.resolve(".serverless-check", relativePath);
  return import(pathToFileURL(absolutePath).href);
}

const previous = {
  GAS_URL: process.env.GAS_URL,
  GAS_BACKEND_SECRET: process.env.GAS_BACKEND_SECRET,
  SESSION_SECRET: process.env.SESSION_SECRET,
  ITEMS_CSV_URL: process.env.ITEMS_CSV_URL,
};

process.env.GAS_URL = "https://script.google.com/macros/s/AKfycbSERVERLESSCHECK/exec";
process.env.GAS_BACKEND_SECRET = "serverless-check-backend-secret";
process.env.SESSION_SECRET = "serverless-check-session-secret-at-least-32-characters";
delete process.env.ITEMS_CSV_URL;

try {
  const health = await load("api/health.js");
  const healthRes = createResponse();
  await health.default({ method: "GET", headers: {} }, healthRes);
  assert.equal(healthRes.statusCode, 200);
  assert.equal(healthRes.body?.success, true);

  const me = await load("api/auth/me.js");
  const meRes = createResponse();
  await me.default({ method: "GET", headers: {} }, meRes);
  assert.equal(meRes.statusCode, 401);

  const requests = await load("api/requests.js");
  const requestsRes = createResponse();
  await requests.default({ method: "GET", headers: {}, url: "/api/requests" }, requestsRes);
  assert.equal(requestsRes.statusCode, 401);

  const config = await load("api/config.js");
  const configRes = createResponse();
  await config.default({ method: "GET", headers: {} }, configRes);
  assert.equal(configRes.statusCode, 401);

  await load("api/auth/login.js");
  await load("api/auth/logout.js");
  await load("api/auth/change-pin.js");
  await load("api/auth/switch-role.js");
  await load("api/items.js");
  await load("api/employees.js");
  await load("api/test-connection.js");

  console.log("Serverless ESM smoke test passed (11 endpoints + auth guard).");
} finally {
  for (const [key, value] of Object.entries(previous)) {
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
}
