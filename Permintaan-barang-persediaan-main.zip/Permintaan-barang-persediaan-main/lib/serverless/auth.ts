import { createHmac, timingSafeEqual } from "node:crypto";
import {
  fetchTextWithTimeout,
  getConfiguredGasUrl,
  parseGasJson,
} from "./shared.js";

export type AppRole = "PEMOHON" | "PETUGAS_GUDANG" | "APPROVER" | "ADMIN";

export interface SessionUser {
  nrk: string;
  name: string;
  jobTitle: string;
  appRole: AppRole; // Alias kompatibilitas untuk activeRole
  activeRole: AppRole;
  roles: AppRole[];
  mustChangePin: boolean;
}

interface SessionPayload {
  user: SessionUser;
  exp: number;
}

const COOKIE_NAME = "pb_session";
const SESSION_SECONDS = 8 * 60 * 60;
const VALID_ROLES: AppRole[] = ["PEMOHON", "PETUGAS_GUDANG", "APPROVER", "ADMIN"];

function isAppRole(value: unknown): value is AppRole {
  return VALID_ROLES.includes(String(value || "") as AppRole);
}

export function normalizeSessionUser(input: any): SessionUser {
  const legacyRole: AppRole = isAppRole(input?.appRole) ? input.appRole : "PEMOHON";
  const sourceRoles = Array.isArray(input?.roles) ? input.roles.filter(isAppRole) : [legacyRole];
  const roles = Array.from(new Set<AppRole>(sourceRoles.length ? sourceRoles : [legacyRole]));
  const activeRole = isAppRole(input?.activeRole) && roles.includes(input.activeRole)
    ? input.activeRole
    : roles.includes(legacyRole)
      ? legacyRole
      : roles[0];

  return {
    nrk: String(input?.nrk || ""),
    name: String(input?.name || ""),
    jobTitle: String(input?.jobTitle || ""),
    appRole: activeRole,
    activeRole,
    roles,
    mustChangePin: Boolean(input?.mustChangePin),
  };
}

function requiredEnv(name: string): string {
  const value = process.env[name]?.trim() || "";
  if (!value) throw new Error(`${name} belum dikonfigurasi.`);
  return value;
}

function base64UrlEncode(value: string): string {
  return Buffer.from(value, "utf8").toString("base64url");
}

function base64UrlDecode(value: string): string {
  return Buffer.from(value, "base64url").toString("utf8");
}

function sign(value: string): string {
  return createHmac("sha256", requiredEnv("SESSION_SECRET"))
    .update(value)
    .digest("base64url");
}

function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

export function createSessionToken(user: SessionUser): string {
  const payload: SessionPayload = {
    user: normalizeSessionUser(user),
    exp: Math.floor(Date.now() / 1000) + SESSION_SECONDS,
  };
  const encoded = base64UrlEncode(JSON.stringify(payload));
  return `${encoded}.${sign(encoded)}`;
}

export function parseCookies(req: any): Record<string, string> {
  const header: string = typeof req.headers?.cookie === "string" ? String(req.headers.cookie) : "";
  return header.split(";").reduce<Record<string, string>>((cookies, part) => {
    const index = part.indexOf("=");
    if (index < 0) return cookies;
    const key = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    if (key) cookies[key] = decodeURIComponent(value);
    return cookies;
  }, {});
}

export function readSession(req: any): SessionUser | null {
  try {
    const token = parseCookies(req)[COOKIE_NAME];
    if (!token) return null;
    const [encoded, signature] = token.split(".");
    if (!encoded || !signature || !safeEqual(sign(encoded), signature)) return null;
    const payload = JSON.parse(base64UrlDecode(encoded)) as SessionPayload;
    if (!payload?.user || payload.exp <= Math.floor(Date.now() / 1000)) return null;
    return normalizeSessionUser(payload.user);
  } catch {
    return null;
  }
}

export function setSessionCookie(res: any, user: SessionUser): void {
  const secure = process.env.VERCEL || process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader(
    "Set-Cookie",
    `${COOKIE_NAME}=${encodeURIComponent(createSessionToken(user))}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_SECONDS}${secure}`
  );
}

export function clearSessionCookie(res: any): void {
  const secure = process.env.VERCEL || process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader(
    "Set-Cookie",
    `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`
  );
}

export function requireSession(req: any, res: any): SessionUser | null {
  const user = readSession(req);
  if (!user) {
    res.status(401).json({ success: false, error: "Sesi tidak valid atau sudah berakhir." });
    return null;
  }
  if (user.mustChangePin && !String(req.url || "").includes("change-pin")) {
    res.status(403).json({ success: false, error: "PIN awal wajib diganti sebelum menggunakan aplikasi.", code: "PIN_CHANGE_REQUIRED" });
    return null;
  }
  return user;
}

export async function callGas(action: string, payload: Record<string, unknown> = {}): Promise<any> {
  const gasUrl = getConfiguredGasUrl();
  const backendSecret = requiredEnv("GAS_BACKEND_SECRET");
  const { response, text } = await fetchTextWithTimeout(
    gasUrl,
    {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({ action, backendSecret, ...payload }),
    },
    45000
  );

  if (!response.ok) throw new Error(`Google Apps Script merespons HTTP ${response.status}.`);
  const result = parseGasJson(text);
  if (!result?.success) throw new Error(result?.error || "Google Apps Script mengembalikan status gagal.");
  return result;
}

export function isRole(user: SessionUser, ...roles: AppRole[]): boolean {
  const activeRole = user.activeRole || user.appRole;
  return activeRole === "ADMIN" || roles.includes(activeRole);
}

export function hasAssignedRole(user: SessionUser, role: AppRole): boolean {
  return user.roles.includes(role);
}
