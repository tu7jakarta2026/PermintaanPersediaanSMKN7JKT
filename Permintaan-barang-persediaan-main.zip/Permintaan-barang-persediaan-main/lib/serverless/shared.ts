const GAS_PATTERN = /^https:\/\/script\.google\.com\/macros\/s\/[^/\s]+\/exec$/;

export function getConfiguredGasUrl(): string {
  const url = process.env.GAS_URL?.trim() || "";
  if (!url) {
    throw new Error("GAS_URL belum dikonfigurasi di Environment Variables Vercel.");
  }
  if (!GAS_PATTERN.test(url)) {
    throw new Error("Format GAS_URL tidak valid. URL harus berakhiran /exec.");
  }
  return url;
}

export function validateGoogleAppsScriptUrl(value: unknown): string {
  const url = typeof value === "string" ? value.trim() : "";
  if (!GAS_PATTERN.test(url)) {
    throw new Error("URL Google Apps Script tidak valid.");
  }
  return url;
}

export async function fetchTextWithTimeout(
  url: string,
  init: RequestInit = {},
  timeoutMs = 20000
): Promise<{ response: Response; text: string }> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...init,
      signal: controller.signal,
      redirect: "follow",
    });
    const text = await response.text();
    return { response, text };
  } finally {
    clearTimeout(timeout);
  }
}

export function parseGasJson(text: string): any {
  try {
    return JSON.parse(text);
  } catch {
    const normalized = text.trim().toLowerCase();
    if (normalized.startsWith("<!doctype") || normalized.startsWith("<html")) {
      throw new Error(
        "Apps Script mengembalikan HTML. Pastikan deployment Web App memakai akses Anyone dan gunakan URL /exec."
      );
    }
    throw new Error("Respons Apps Script bukan JSON valid.");
  }
}

export function setApiHeaders(res: any): void {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
}
