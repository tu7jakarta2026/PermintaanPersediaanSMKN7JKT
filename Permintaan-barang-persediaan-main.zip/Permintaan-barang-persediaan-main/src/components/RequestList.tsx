import React, { useMemo, useState } from "react";
import { RequestStatus, InventoryRequest } from "../types";
import { AppRole, AuthUser } from "../lib/auth";
import {
  Calendar,
  CheckCircle2,
  ClipboardCheck,
  Clock3,
  Eye,
  Filter,
  PackageCheck,
  Plus,
  Search,
  ShieldCheck,
  UserCheck,
  XCircle,
} from "lucide-react";

interface RequestListProps {
  requests: InventoryRequest[];
  currentRole: AppRole;
  onViewDetails: (request: InventoryRequest) => void;
  onAction: (id: string, actionType: "receive" | "approve" | "reject", operatorName: string, notes: string) => Promise<boolean>;
  onOpenValidate: (request: InventoryRequest) => void;
  onOpenConfirmReceipt: (request: InventoryRequest) => void;
  onOpenCreate: () => void;
  currentEmployee: AuthUser;
  disabled?: boolean;
}

export const STATUS_LABELS: Record<RequestStatus, string> = {
  [RequestStatus.PENDING_RECEIPT]: "Menunggu Pemeriksaan Gudang",
  [RequestStatus.PENDING_APPROVAL]: "Menunggu Persetujuan",
  [RequestStatus.PENDING_VALIDATION]: "Menunggu Penyerahan",
  [RequestStatus.AWAITING_REQUESTER_CONFIRMATION]: "Menunggu Konfirmasi Pemohon",
  [RequestStatus.VALIDATED]: "Selesai",
  [RequestStatus.REJECTED]: "Ditolak",
};

const STATUS_STYLES: Record<RequestStatus, string> = {
  [RequestStatus.PENDING_RECEIPT]: "bg-blue-50 text-blue-700 border-blue-100",
  [RequestStatus.PENDING_APPROVAL]: "bg-violet-50 text-violet-700 border-violet-100",
  [RequestStatus.PENDING_VALIDATION]: "bg-amber-50 text-amber-700 border-amber-100",
  [RequestStatus.AWAITING_REQUESTER_CONFIRMATION]: "bg-cyan-50 text-cyan-700 border-cyan-100",
  [RequestStatus.VALIDATED]: "bg-emerald-50 text-emerald-700 border-emerald-100",
  [RequestStatus.REJECTED]: "bg-rose-50 text-rose-700 border-rose-100",
};

export default function RequestList({
  requests,
  currentRole,
  onViewDetails,
  onAction,
  onOpenValidate,
  onOpenConfirmReceipt,
  onOpenCreate,
  currentEmployee,
  disabled = false,
}: RequestListProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [openAction, setOpenAction] = useState<{ id: string; action: "receive" | "approve" | "reject" } | null>(null);
  const [notes, setNotes] = useState("");
  const [submittingAction, setSubmittingAction] = useState(false);

  const filtered = useMemo(() => {
    const keyword = searchTerm.trim().toLowerCase();
    return [...requests]
      .filter((request) => {
        const matchesSearch = !keyword || [request.id, request.itemName, request.requesterName, request.purpose]
          .some((value) => String(value || "").toLowerCase().includes(keyword));
        const matchesStatus = statusFilter === "ALL" || request.status === statusFilter;
        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime() || b.id.localeCompare(a.id));
  }, [requests, searchTerm, statusFilter]);

  const submitAction = async () => {
    if (!openAction || disabled || submittingAction) return;
    setSubmittingAction(true);
    try {
      const success = await onAction(openAction.id, openAction.action, currentEmployee.name, notes.trim());
      if (success) {
        setOpenAction(null);
        setNotes("");
      }
    } finally {
      setSubmittingAction(false);
    }
  };

  const canReceive = (request: InventoryRequest) =>
    ["PETUGAS_GUDANG", "ADMIN"].includes(currentRole) && request.status === RequestStatus.PENDING_RECEIPT;
  const canApprove = (request: InventoryRequest) =>
    ["APPROVER", "ADMIN"].includes(currentRole) && request.status === RequestStatus.PENDING_APPROVAL;
  const canHandover = (request: InventoryRequest) =>
    ["PETUGAS_GUDANG", "ADMIN"].includes(currentRole) && request.status === RequestStatus.PENDING_VALIDATION;
  const canConfirmReceipt = (request: InventoryRequest) =>
    request.status === RequestStatus.AWAITING_REQUESTER_CONFIRMATION && (
      currentRole === "ADMIN" || (
        currentRole === "PEMOHON" && String(request.requesterNrk || "").trim() === currentEmployee.nrk
      )
    );

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 justify-between">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="Cari ID, barang, pemohon, atau keperluan..." className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          {["PEMOHON", "ADMIN"].includes(currentRole) && (
            <button disabled={disabled} onClick={onOpenCreate} className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white text-xs font-bold flex items-center justify-center gap-1.5">
              <Plus className="w-4 h-4" /> Buat Permintaan
            </button>
          )}
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          {[{ value: "ALL", label: "Semua" }, ...Object.values(RequestStatus).map((value) => ({ value, label: STATUS_LABELS[value] }))].map((tab) => (
            <button key={tab.value} onClick={() => setStatusFilter(tab.value)} className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-[11px] font-bold ${statusFilter === tab.value ? "bg-slate-900 text-white" : "bg-slate-50 text-slate-600 border border-slate-100 hover:bg-slate-100"}`}>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {currentRole === "ADMIN" && (
        <div className="rounded-2xl border border-violet-100 bg-violet-50 px-4 py-3 text-xs text-violet-800 flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <p><strong>Mode Super Admin aktif.</strong> Anda dapat menjalankan seluruh tahapan. Setiap tindakan otomatis dicatat di tab Google Sheets <strong>Audit_Log</strong>.</p>
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <PackageCheck className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-800 mt-3">Tidak ada permintaan ditemukan</h3>
          <p className="text-xs text-slate-500 mt-1">Ubah filter atau buat permintaan baru.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {filtered.map((request) => {
            const hasAction = canReceive(request) || canApprove(request) || canHandover(request) || canConfirmReceipt(request);
            return (
              <article key={request.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-600 rounded px-2 py-1">{request.id}</span>
                      <span className={`text-[10px] font-bold border rounded-full px-2 py-1 ${STATUS_STYLES[request.status]}`}>{STATUS_LABELS[request.status]}</span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mt-3">{request.itemName}</h3>
                    <p className="text-sm font-semibold text-blue-700 mt-0.5">{request.quantity} {request.unit}</p>
                  </div>
                  <div className="p-2 rounded-xl bg-blue-50 text-blue-600"><PackageCheck className="w-5 h-5" /></div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                  <div className="rounded-xl bg-slate-50 p-3"><span className="text-[9px] uppercase tracking-wider font-bold text-slate-400">Pemohon</span><p className="font-semibold text-slate-700 mt-1 line-clamp-2">{request.requesterName}</p></div>
                  <div className="rounded-xl bg-slate-50 p-3"><span className="text-[9px] uppercase tracking-wider font-bold text-slate-400">Tanggal</span><p className="font-semibold text-slate-700 mt-1 flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{request.requestDate}</p></div>
                </div>

                <p className="text-xs text-slate-500 mt-3 leading-relaxed line-clamp-2">{request.purpose}</p>

                <div className="mt-4 grid grid-cols-5 gap-1.5">
                  {[
                    { label: "Diajukan", done: true },
                    { label: "Diperiksa", done: [RequestStatus.PENDING_APPROVAL, RequestStatus.PENDING_VALIDATION, RequestStatus.AWAITING_REQUESTER_CONFIRMATION, RequestStatus.VALIDATED].includes(request.status) },
                    { label: "Disetujui", done: [RequestStatus.PENDING_VALIDATION, RequestStatus.AWAITING_REQUESTER_CONFIRMATION, RequestStatus.VALIDATED].includes(request.status) },
                    { label: "Diserahkan", done: [RequestStatus.AWAITING_REQUESTER_CONFIRMATION, RequestStatus.VALIDATED].includes(request.status) },
                    { label: "Dikonfirmasi", done: request.status === RequestStatus.VALIDATED },
                  ].map((step) => (
                    <div key={step.label} className="min-w-0"><div className={`h-1 rounded-full ${step.done ? "bg-blue-600" : request.status === RequestStatus.REJECTED ? "bg-rose-200" : "bg-slate-200"}`} /><p className={`text-[8px] text-center mt-1 truncate ${step.done ? "text-blue-700 font-bold" : "text-slate-400"}`}>{step.label}</p></div>
                  ))}
                </div>

                {openAction?.id === request.id ? (
                  <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-3">
                    <div className="flex justify-between items-center">
                      <p className="text-[10px] uppercase tracking-wider font-bold text-slate-500">{openAction.action === "receive" ? "Konfirmasi Pemeriksaan Gudang" : openAction.action === "approve" ? "Konfirmasi Persetujuan" : "Konfirmasi Penolakan"}</p>
                      <button disabled={disabled || submittingAction} onClick={() => setOpenAction(null)} className="text-[10px] font-semibold text-slate-400 disabled:opacity-40">Batal</button>
                    </div>
                    {currentRole === "ADMIN" && <p className="text-[10px] text-violet-700 bg-violet-50 border border-violet-100 p-2 rounded-lg">Tindakan akan dicatat sebagai Administrator yang bertindak sesuai tahapan ini.</p>}
                    <textarea disabled={disabled || submittingAction} value={notes} onChange={(event) => setNotes(event.target.value)} rows={2} placeholder={currentRole === "ADMIN" ? "Catatan tindakan Admin (opsional)..." : "Catatan tindak lanjut (opsional)..."} className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-xs resize-none disabled:opacity-60" />
                    <button disabled={disabled || submittingAction} onClick={() => void submitAction()} className={`w-full py-2 rounded-lg text-white text-xs font-bold disabled:bg-slate-300 ${openAction.action === "reject" ? "bg-rose-600 hover:bg-rose-700" : "bg-blue-600 hover:bg-blue-700"}`}>{submittingAction ? "Memproses..." : "Kirim Tindakan"}</button>
                  </div>
                ) : (
                  <div className="mt-auto pt-4 border-t border-slate-100 flex flex-wrap gap-2 items-center">
                    {canReceive(request) && <button disabled={disabled} onClick={() => { setNotes(""); setOpenAction({ id: request.id, action: "receive" }); }} className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white text-xs font-bold flex items-center gap-1"><ClipboardCheck className="w-3.5 h-3.5" /> Periksa & Teruskan</button>}
                    {canApprove(request) && <><button disabled={disabled} onClick={() => { setNotes(""); setOpenAction({ id: request.id, action: "approve" }); }} className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white text-xs font-bold flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> Setujui</button><button disabled={disabled} onClick={() => { setNotes(""); setOpenAction({ id: request.id, action: "reject" }); }} className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 disabled:bg-slate-100 text-rose-700 border border-rose-100 text-xs font-bold flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> Tolak</button></>}
                    {canHandover(request) && <button disabled={disabled} onClick={() => onOpenValidate(request)} className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 disabled:bg-slate-300 text-white text-xs font-bold flex items-center gap-1"><UserCheck className="w-3.5 h-3.5" /> Serahkan & Foto</button>}
                    {canConfirmReceipt(request) && <button disabled={disabled} onClick={() => onOpenConfirmReceipt(request)} className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white text-xs font-bold flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> {currentRole === "ADMIN" ? "Konfirmasi sebagai Admin" : "Konfirmasi Diterima"}</button>}
                    {!hasAction && currentRole !== "PEMOHON" && <span className="text-[10px] text-slate-400 flex items-center gap-1"><Clock3 className="w-3 h-3" /> Tidak ada tindakan pada status ini</span>}
                    <button disabled={disabled} onClick={() => onViewDetails(request)} className="ml-auto px-2.5 py-1.5 rounded-lg text-slate-500 hover:text-blue-700 hover:bg-blue-50 disabled:opacity-40 text-xs font-bold flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> Rincian</button>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
