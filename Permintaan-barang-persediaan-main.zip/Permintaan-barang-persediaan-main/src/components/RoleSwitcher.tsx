import React from "react";
import { AppRole, AuthUser, ROLE_LABELS } from "../lib/auth";
import { BriefcaseBusiness, ChevronDown } from "lucide-react";

interface RoleSwitcherProps {
  user: AuthUser;
  disabled?: boolean;
  onChange: (role: AppRole) => void;
}

export default function RoleSwitcher({ user, disabled, onChange }: RoleSwitcherProps) {
  if (user.roles.length <= 1) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-slate-200">
        <BriefcaseBusiness className="w-3.5 h-3.5 text-blue-400" />
        {ROLE_LABELS[user.activeRole]}
      </div>
    );
  }

  return (
    <label className="relative flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-slate-200 hover:border-slate-600">
      <BriefcaseBusiness className="w-3.5 h-3.5 text-blue-400 shrink-0" />
      <span className="hidden sm:inline text-slate-400">Mode:</span>
      <select
        value={user.activeRole}
        disabled={disabled}
        onChange={(event) => onChange(event.target.value as AppRole)}
        className="appearance-none bg-transparent pr-5 outline-none cursor-pointer disabled:cursor-wait max-w-[170px]"
        aria-label="Pilih role aktif"
      >
        {user.roles.map((role) => (
          <option key={role} value={role} className="text-slate-900 bg-white">
            {ROLE_LABELS[role]}
          </option>
        ))}
      </select>
      <ChevronDown className="w-3 h-3 absolute right-2.5 text-slate-400 pointer-events-none" />
    </label>
  );
}
