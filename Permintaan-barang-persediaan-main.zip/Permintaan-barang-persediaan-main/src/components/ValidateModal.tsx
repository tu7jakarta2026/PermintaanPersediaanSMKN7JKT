import React, { useEffect, useRef, useState } from "react";
import { AlertTriangle, Check, ImageDown, MessageSquare, Upload, X } from "lucide-react";
import { AuthUser } from "../lib/auth";
import { compressImageFile, formatFileSize } from "../lib/image";

interface ValidateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onValidate: (id: string, validatorName: string, photoBase64: string, notes: string) => Promise<boolean>;
  requestId: string;
  itemName: string;
  quantity: number;
  unit: string;
  currentEmployee: AuthUser | null;
  isSubmitting?: boolean;
}

export default function ValidateModal({
  isOpen,
  onClose,
  onValidate,
  requestId,
  itemName,
  quantity,
  unit,
  currentEmployee,
  isSubmitting = false,
}: ValidateModalProps) {
  const [validatorName, setValidatorName] = useState("");
  const [photo, setPhoto] = useState("");
  const [notes, setNotes] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const [isCompressing, setIsCompressing] = useState(false);
  const [photoInfo, setPhotoInfo] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setValidatorName(currentEmployee?.name || "");
    setPhoto("");
    setNotes("");
    setPhotoInfo("");
    setIsCompressing(false);
  }, [isOpen, requestId, currentEmployee?.name]);

  if (!isOpen) return null;

  const handleFile = async (file?: File) => {
    if (!file || isSubmitting || isCompressing) return;
    setIsCompressing(true);
    setPhotoInfo("Mengompres foto agar unggahan lebih cepat...");
    try {
      const result = await compressImageFile(file);
      setPhoto(result.dataUrl);
      setPhotoInfo(`${formatFileSize(result.originalBytes)} → ${formatFileSize(result.compressedBytes)} · ${result.width}×${result.height}px`);
    } catch (error: any) {
      alert(error?.message || "Gagal memproses foto.");
      setPhotoInfo("");
    } finally {
      setIsCompressing(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleDrag = (event: React.DragEvent) => {
    event.preventDefault();
    event.stopPropagation();
    if (isSubmitting || isCompressing) return;
    setDragActive(event.type === "dragenter" || event.type === "dragover");
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    event.stopPropagation();
    setDragActive(false);
    void handleFile(event.dataTransfer.files?.[0]);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (isSubmitting || isCompressing) return;
    if (!validatorName.trim()) {
      alert("Nama petugas tidak tersedia dari sesi login.");
      return;
    }
    if (!photo) {
      alert("Mohon lampirkan foto penyerahan barang.");
      return;
    }

    const success = await onValidate(requestId, validatorName, photo, notes.trim());
    if (success) onClose();
  };

  const isAdmin = currentEmployee?.activeRole === "ADMIN";

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full overflow-hidden animate-scale-up">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">{requestId}</span>
            <div>
              <h3 className="text-base font-semibold text-slate-800">Penyerahan Barang</h3>
              {isAdmin && <p className="text-[10px] font-semibold text-violet-600">Tindakan Administrator dicatat di Audit_Log</p>}
            </div>
          </div>
          <button type="button" disabled={isSubmitting} onClick={onClose} className="p-1.5 rounded-lg bg-slate-100 text-slate-500 disabled:opacity-40"><X className="w-4 h-4" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3 bg-amber-50/60 border border-amber-100 rounded-xl text-xs text-slate-700">
            <span className="font-semibold block mb-0.5">Barang yang akan diserahkan</span>
            <p className="font-bold text-slate-900">{itemName} — {quantity} {unit}</p>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-600">Diserahkan oleh</label>
            <input readOnly value={validatorName} className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-slate-100 text-slate-600" />
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-600">Foto Serah Terima Fisik <span className="text-rose-500">*</span></label>
            {photo ? (
              <div className="relative border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                <img src={photo} alt="Preview serah terima" className="w-full h-44 object-cover" />
                <button type="button" disabled={isSubmitting} onClick={() => { setPhoto(""); setPhotoInfo(""); }} className="absolute top-2 right-2 p-1.5 bg-slate-900/75 text-white rounded-lg disabled:opacity-40"><X className="w-3.5 h-3.5" /></button>
                <div className="absolute bottom-0 inset-x-0 bg-slate-900/70 text-white px-3 py-1.5 text-[10px] flex items-center justify-between">
                  <span className="flex items-center gap-1"><Check className="w-3 h-3 text-emerald-400" /> Foto siap diunggah</span>
                  <button type="button" disabled={isSubmitting} onClick={() => fileInputRef.current?.click()} className="underline disabled:opacity-40">Ubah</button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                disabled={isSubmitting || isCompressing}
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`w-full border-2 border-dashed rounded-xl p-6 text-center transition-all flex flex-col items-center gap-2 disabled:cursor-wait ${dragActive ? "border-indigo-500 bg-indigo-50" : "border-slate-200 bg-slate-50 hover:border-indigo-400"}`}
              >
                {isCompressing ? <ImageDown className="w-8 h-8 text-indigo-500 animate-pulse" /> : <Upload className="w-8 h-8 text-slate-400" />}
                <div>
                  <p className="text-xs font-semibold text-slate-700">{isCompressing ? "Sedang mengompres foto..." : "Klik atau tarik foto ke sini"}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">JPG/PNG · maksimal 12 MB sebelum kompresi</p>
                </div>
              </button>
            )}
            {photoInfo && <p className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1"><ImageDown className="w-3 h-3" /> {photoInfo}</p>}
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(event) => void handleFile(event.target.files?.[0])} />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5 text-slate-400" /> Catatan Penyerahan (Opsional)</label>
            <textarea rows={2} value={notes} disabled={isSubmitting} onChange={(event) => setNotes(event.target.value)} placeholder={isAdmin ? "Catatan tindakan Administrator (opsional)..." : "Contoh: Barang diserahkan dalam kondisi tersegel..."} className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-slate-50 resize-none disabled:opacity-60" />
          </div>

          <div className="flex gap-2 p-3 bg-amber-50 text-[10px] text-amber-800 rounded-xl border border-amber-100">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
            <p>Setelah disimpan, status menjadi <strong>Menunggu Konfirmasi Pemohon</strong>. Pemohon atau Administrator dapat langsung mengonfirmasi penerimaan.</p>
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100">
            <button type="button" disabled={isSubmitting} onClick={onClose} className="px-4 py-2 border border-slate-200 text-slate-600 text-xs font-medium rounded-lg disabled:opacity-40">Batal</button>
            <button type="submit" disabled={!photo || !validatorName.trim() || isSubmitting || isCompressing} className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-semibold rounded-lg">
              <Check className="w-3.5 h-3.5" /> {isSubmitting ? "Memproses..." : "Simpan Penyerahan"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
