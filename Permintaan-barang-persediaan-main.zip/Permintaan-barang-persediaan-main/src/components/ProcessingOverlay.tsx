import React from "react";
import { CheckCircle2, CloudUpload, FileSpreadsheet, PackageCheck } from "lucide-react";

export interface ProcessingState {
  visible: boolean;
  title: string;
  message: string;
  detail?: string;
  progress?: number;
}

interface ProcessingOverlayProps {
  state: ProcessingState;
}

export default function ProcessingOverlay({ state }: ProcessingOverlayProps) {
  if (!state.visible) return null;
  const progress = Math.max(8, Math.min(96, state.progress ?? 35));

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/65 backdrop-blur-sm flex items-center justify-center p-4" role="status" aria-live="polite">
      <div className="w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-white shadow-2xl">
        <div className="relative bg-gradient-to-br from-blue-700 via-indigo-700 to-slate-900 px-6 pt-7 pb-8 text-white overflow-hidden">
          <div className="absolute -top-16 -right-12 w-44 h-44 rounded-full bg-white/10" />
          <div className="absolute -bottom-20 -left-16 w-52 h-52 rounded-full bg-cyan-400/10" />
          <div className="relative flex items-center justify-center gap-4 py-3">
            <div className="processing-float p-3 rounded-2xl bg-white/10 border border-white/15"><PackageCheck className="w-8 h-8" /></div>
            <div className="processing-dots flex gap-1.5"><span /><span /><span /></div>
            <div className="processing-float processing-delay p-3 rounded-2xl bg-white/10 border border-white/15"><CloudUpload className="w-8 h-8" /></div>
            <div className="processing-dots flex gap-1.5"><span /><span /><span /></div>
            <div className="processing-float p-3 rounded-2xl bg-white/10 border border-white/15"><FileSpreadsheet className="w-8 h-8" /></div>
          </div>
          <h2 className="relative mt-3 text-center text-lg font-bold">{state.title}</h2>
          <p className="relative mt-1 text-center text-xs text-blue-100">{state.message}</p>
        </div>

        <div className="p-6">
          <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
            <div className="processing-progress h-full rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
          <div className="mt-4 flex items-start gap-2.5 rounded-2xl border border-blue-100 bg-blue-50 p-3 text-xs text-blue-900">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-blue-600" />
            <p>{state.detail || "Mohon jangan menutup halaman atau menekan tombol berulang kali."}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
