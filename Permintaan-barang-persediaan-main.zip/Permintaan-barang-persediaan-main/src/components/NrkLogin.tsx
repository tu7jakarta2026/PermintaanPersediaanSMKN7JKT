import React, { useState } from "react";
import { KeyRound, LockKeyhole, ShieldCheck, UserRound, Eye, EyeOff } from "lucide-react";
import { AuthUser, login } from "../lib/auth";

interface Props {
  onLogin: (user: AuthUser) => void;
}

export default function NrkLogin({ onLogin }: Props) {
  const [nrk, setNrk] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");
    if (!/^\d{4,20}$/.test(nrk.trim())) {
      setError("Masukkan NRK yang valid.");
      return;
    }
    if (!/^\d{6}$/.test(pin)) {
      setError("PIN harus terdiri dari 6 digit angka.");
      return;
    }
    setLoading(true);
    try {
      const user = await login(nrk.trim(), pin);
      onLogin(user);
    } catch (err: any) {
      setError(err?.message || "Login gagal.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-5 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(37,99,235,0.22),transparent_36%),radial-gradient(circle_at_bottom_left,rgba(14,165,233,0.13),transparent_30%)]" />
      <div className="relative w-full max-w-md">
        <div className="mb-6 text-center text-white">
          <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center mx-auto shadow-xl shadow-blue-950/40 mb-4">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Permintaan Barang Persediaan</h1>
          <p className="text-sm text-slate-400 mt-1">SMKN 7 Jakarta · Sistem akses berbasis peran</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-white/10 shadow-2xl p-6 sm:p-8 space-y-5">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Masuk dengan NRK</h2>
            <p className="text-xs text-slate-500 mt-1">Peran dashboard ditentukan otomatis dari akun Anda.</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-600">NRK / NIKKI</label>
            <div className="relative">
              <UserRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                autoFocus
                inputMode="numeric"
                autoComplete="username"
                value={nrk}
                onChange={(event) => setNrk(event.target.value.replace(/\D/g, ""))}
                placeholder="Masukkan NRK"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-600">PIN 6 Digit</label>
            <div className="relative">
              <LockKeyhole className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type={showPin ? "text" : "password"}
                inputMode="numeric"
                autoComplete="current-password"
                maxLength={6}
                value={pin}
                onChange={(event) => setPin(event.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="••••••"
                className="w-full pl-10 pr-11 py-3 rounded-xl border border-slate-200 bg-slate-50 text-sm tracking-[0.35em] focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button type="button" onClick={() => setShowPin((value) => !value)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700">
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && <div className="rounded-xl bg-rose-50 border border-rose-100 px-3 py-2.5 text-xs font-semibold text-rose-700">{error}</div>}

          <button disabled={loading} className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-200 transition-colors">
            <KeyRound className="w-4 h-4" />
            {loading ? "Memverifikasi..." : "Masuk ke Dashboard"}
          </button>

          <p className="text-[11px] text-slate-400 text-center leading-relaxed">Sesi disimpan dalam cookie HttpOnly dan berakhir otomatis setelah 8 jam.</p>
        </form>
      </div>
    </div>
  );
}
