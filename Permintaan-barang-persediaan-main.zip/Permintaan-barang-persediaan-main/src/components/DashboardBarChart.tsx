import React, { useState } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from "recharts";
import { InventoryRequest } from "../types";
import { BarChart3, Info, Calendar, TrendingUp } from "lucide-react";

interface DashboardBarChartProps {
  requests: InventoryRequest[];
}

interface MonthlyBreakdown {
  [monthYear: string]: number;
}

interface BarChartItem {
  itemName: string;
  totalQuantity: number;
  requestCount: number;
  unit: string;
  monthlyBreakdown: MonthlyBreakdown;
}

interface AxisTickProps {
  x?: number;
  y?: number;
  payload?: {
    value?: string;
  };
}

const INDO_MONTHS = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
];

const TICK_LINE_LENGTH = 14;

function splitAxisLabel(rawValue: string): string[] {
  const value = rawValue.trim().replace(/\s+/g, " ");
  if (!value) return [""];
  if (value.length <= TICK_LINE_LENGTH) return [value];

  const words = value.split(" ");
  const lines: string[] = [];
  let current = "";
  let consumedWords = 0;

  for (const word of words) {
    const normalizedWord =
      word.length > TICK_LINE_LENGTH
        ? `${word.slice(0, TICK_LINE_LENGTH - 1)}…`
        : word;
    const candidate = current ? `${current} ${normalizedWord}` : normalizedWord;

    if (candidate.length <= TICK_LINE_LENGTH) {
      current = candidate;
      consumedWords += 1;
      continue;
    }

    if (current) {
      lines.push(current);
      current = "";
    }

    if (lines.length === 2) break;

    current = normalizedWord;
    consumedWords += 1;
  }

  if (current && lines.length < 2) lines.push(current);

  const hasHiddenText = consumedWords < words.length;
  if (hasHiddenText && lines.length) {
    const lastIndex = lines.length - 1;
    const lastLine = lines[lastIndex].replace(/…$/, "");
    lines[lastIndex] = `${lastLine.slice(0, TICK_LINE_LENGTH - 1).trimEnd()}…`;
  }

  return lines.slice(0, 2);
}

function CustomXAxisTick({ x = 0, y = 0, payload }: AxisTickProps) {
  const lines = splitAxisLabel(String(payload?.value || ""));

  return (
    <g transform={`translate(${x},${y})`}>
      <text
        x={0}
        y={0}
        dy={12}
        textAnchor="middle"
        fill="#64748b"
        fontSize={10}
        fontWeight={600}
      >
        {lines.map((line, index) => (
          <tspan key={`${line}-${index}`} x={0} dy={index === 0 ? 0 : 12}>
            {line}
          </tspan>
        ))}
      </text>
    </g>
  );
}

export default function DashboardBarChart({
  requests,
}: DashboardBarChartProps) {
  const [limit, setLimit] = useState<number>(8);

  const totalRequestsCount = requests.length;

  const itemMap: { [name: string]: BarChartItem } = {};

  requests.forEach((req) => {
    if (!req.itemName) return;

    const nameTrimmed = req.itemName.trim();
    const nameKey = nameTrimmed.toLowerCase().replace(/\s+/g, " ");

    let monthLabel = "Lainnya";
    if (req.requestDate) {
      try {
        const d = new Date(req.requestDate);
        if (!Number.isNaN(d.getTime())) {
          monthLabel = `${INDO_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
        } else {
          const parts = req.requestDate.split("-");
          if (parts.length >= 2) {
            const mIdx = Number.parseInt(parts[1], 10) - 1;
            const yr = parts[0];
            if (mIdx >= 0 && mIdx < 12) {
              monthLabel = `${INDO_MONTHS[mIdx]} ${yr}`;
            }
          }
        }
      } catch {
        // Gunakan label fallback.
      }
    }

    if (!itemMap[nameKey]) {
      itemMap[nameKey] = {
        itemName: nameTrimmed,
        totalQuantity: 0,
        requestCount: 0,
        unit: req.unit || "Unit",
        monthlyBreakdown: {},
      };
    }

    const qty = Number(req.quantity) || 0;
    itemMap[nameKey].totalQuantity += qty;
    itemMap[nameKey].requestCount += 1;
    itemMap[nameKey].monthlyBreakdown[monthLabel] =
      (itemMap[nameKey].monthlyBreakdown[monthLabel] || 0) + qty;
  });

  const allItems = Object.values(itemMap).sort(
    (a, b) => b.totalQuantity - a.totalQuantity,
  );
  const displayedItems = allItems.slice(0, limit);

  /*
   * Setiap batang memperoleh ruang minimum agar label tidak bertumpuk.
   * Pada layar kecil grafik dapat digeser horizontal, sedangkan desktop
   * menggunakan lebar card secara penuh tanpa scroll jika ruang mencukupi.
   */
  const chartMinWidth = Math.max(560, displayedItems.length * 84);
  const barSize = displayedItems.length <= 5 ? 38 : 30;

  const colors = [
    "#4f46e5",
    "#3b82f6",
    "#10b981",
    "#f59e0b",
    "#ec4899",
    "#8b5cf6",
    "#06b6d4",
    "#14b8a6",
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data: BarChartItem = payload[0].payload;

      return (
        <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 shadow-2xl max-w-xs text-xs animate-fade-in relative z-50">
          <div className="border-b border-slate-800 pb-2 mb-2.5">
            <span className="text-[9px] uppercase tracking-wider font-extrabold text-indigo-400">
              Barang Terpopuler
            </span>
            <h4 className="font-bold text-sm text-slate-100 mt-0.5 break-words">
              {data.itemName}
            </h4>
            <div className="flex justify-between items-center mt-1.5 text-slate-300 font-mono text-[11px] gap-3">
              <span>Total Kebutuhan:</span>
              <span className="font-bold text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded-lg border border-indigo-500/20 whitespace-nowrap">
                {data.totalQuantity} {data.unit}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              Diajukan sebanyak {data.requestCount} kali
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-[10px] font-bold text-slate-400 flex items-center gap-1.5 uppercase tracking-wide">
              <Calendar className="w-3 h-3 text-indigo-400" />
              Rincian Tiap Bulan
            </p>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {Object.entries(data.monthlyBreakdown).map(([month, qty]) => (
                <div
                  key={month}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 border border-slate-700/50 rounded-full shrink-0"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shadow-[0_0_8px_#818cf8]" />
                  <span className="text-[10px] font-medium text-slate-300">
                    {month}:
                  </span>
                  <span className="text-[10px] font-bold text-indigo-200 font-mono">
                    {qty} {data.unit}
                  </span>
                </div>
              ))}
              {Object.keys(data.monthlyBreakdown).length === 0 && (
                <span className="text-[10px] text-slate-500 italic">
                  Tidak ada data bulanan
                </span>
              )}
            </div>
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-4 sm:p-6 animate-fade-in min-w-0">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 mb-5 gap-4">
        <div className="flex items-start sm:items-center gap-2.5 min-w-0">
          <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100 shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-slate-800 leading-snug">
              Permintaan Barang Paling Banyak Dibutuhkan
            </h3>
            <p className="text-[11px] text-slate-500 leading-relaxed mt-0.5">
              Analisis kebutuhan tertinggi beserta rincian jumlah per bulan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
            Tampilkan
          </span>
          <select
            value={limit}
            onChange={(event) => setLimit(Number(event.target.value))}
            className="text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
          >
            <option value={5}>Top 5 Barang</option>
            <option value={8}>Top 8 Barang</option>
            <option value={12}>Top 12 Barang</option>
            <option value={20}>Top 20 Barang</option>
          </select>
        </div>
      </div>

      {totalRequestsCount === 0 ? (
        <div className="py-12 text-center bg-slate-50 border border-dashed border-slate-200 rounded-xl">
          <Info className="w-6 h-6 text-slate-400 mx-auto mb-2" />
          <p className="text-xs font-semibold text-slate-600">
            Belum ada data barang untuk divisualisasikan.
          </p>
          <p className="text-[10px] text-slate-400 mt-1">
            Masukkan pengajuan barang persediaan baru untuk memicu analisis
            grafik.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-8 items-stretch min-w-0">
          <div className="col-span-1 lg:col-span-8 min-w-0">
            <div className="w-full overflow-x-auto overscroll-x-contain pb-1">
              <div
                className="h-[310px]"
                style={{ minWidth: `${chartMinWidth}px` }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={displayedItems}
                    margin={{ top: 10, right: 12, left: 0, bottom: 4 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="#f1f5f9"
                      vertical={false}
                    />
                    <XAxis
                      dataKey="itemName"
                      tick={<CustomXAxisTick />}
                      axisLine={{ stroke: "#e2e8f0" }}
                      tickLine={false}
                      interval={0}
                      height={54}
                    />
                    <YAxis
                      tick={{
                        fill: "#64748b",
                        fontSize: 10,
                        fontWeight: 500,
                      }}
                      axisLine={false}
                      tickLine={false}
                      width={34}
                      allowDecimals={false}
                    />
                    <Tooltip
                      content={<CustomTooltip />}
                      cursor={{ fill: "#f8fafc" }}
                    />
                    <Bar
                      dataKey="totalQuantity"
                      radius={[6, 6, 0, 0]}
                      barSize={barSize}
                    >
                      {displayedItems.map((entry, index) => (
                        <Cell
                          key={`${entry.itemName}-${index}`}
                          fill={colors[index % colors.length]}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="mt-2 text-center px-2">
              <span className="inline-flex items-start sm:items-center justify-center gap-1 text-[10px] text-slate-400 font-medium leading-relaxed">
                <Info className="w-3 h-3 text-indigo-400 shrink-0 mt-0.5 sm:mt-0" />
                <span>
                  Geser grafik pada layar kecil. Sorot atau ketuk batang untuk
                  melihat rincian bulanan.
                </span>
              </span>
            </div>
          </div>

          <div className="col-span-1 lg:col-span-4 bg-slate-50 border border-slate-100 rounded-xl p-4 flex flex-col justify-between min-w-0">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-3">
                <h4 className="text-xs font-bold text-slate-700 tracking-wide uppercase flex items-center gap-1.5 min-w-0">
                  <TrendingUp className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span className="truncate">Peringkat Kebutuhan</span>
                </h4>
                <span className="text-[10px] bg-indigo-100 text-indigo-700 font-bold px-1.5 py-0.5 rounded-md shrink-0">
                  Top {limit}
                </span>
              </div>

              <div className="space-y-2 max-h-[230px] overflow-y-auto pr-1">
                {displayedItems.map((item, index) => (
                  <div
                    key={`${item.itemName}-${index}`}
                    className="flex items-center justify-between gap-3 p-2.5 bg-white rounded-lg border border-slate-200/60 shadow-sm hover:border-indigo-200 transition-colors"
                    title={`${item.itemName}: ${item.totalQuantity} ${item.unit}`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-mono text-xs font-bold text-slate-400 shrink-0 w-5">
                        {(index + 1).toString().padStart(2, "0")}
                      </span>
                      <p className="text-xs font-semibold text-slate-700 truncate">
                        {item.itemName}
                      </p>
                    </div>
                    <div className="text-right shrink-0 whitespace-nowrap">
                      <span className="text-xs font-bold text-slate-800 font-mono">
                        {item.totalQuantity}
                      </span>
                      <span className="text-[9px] font-bold text-slate-400 ml-1">
                        {item.unit}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200/60 flex justify-between items-center gap-3 text-[11px] text-slate-500">
              <span>Keberagaman Jenis Barang:</span>
              <span className="font-extrabold text-slate-800 whitespace-nowrap">
                {allItems.length} Jenis
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
