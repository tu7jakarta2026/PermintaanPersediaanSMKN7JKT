import React, { useEffect, useRef, useState } from "react";
import { CheckCircle2, FileImage, ImageDown, MessageSquare, PackageCheck, ShieldCheck, Upload, X } from "lucide-react";
import { AuthUser } from "../lib/auth";
import { compressImageFile, formatFileSize } from "../lib/image";
import { InventoryRequest, ReceiptCondition } from "../types";

interface ConfirmReceiptModalProps {
  isOpen: boolean;
  request: InventoryRequest | null;
  currentUser: AuthUser;
  isSubmitting?: boolean;
  onClose: () => void;
  onConfirm: (id: string, condition: ReceiptCondition, notes: string, photoBase64: string) => Promise<boolean>;
}

export default function ConfirmReceiptModal({
  isOpen,
  request,
  currentUser,
  isSubmitting = false,
  onClose,
  onConfirm,
}: ConfirmReceiptModalProps) {
  const [condition, setCondition] = useState<ReceiptCondition>("DITERIMA_BAIK");
  const [notes, setNotes] = useState("");
  const [photo, setPhoto] = useState("");
  const [photoInfo, setPhotoInfo] = useState("");
  const [isCompressing, setIsCompressing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setCondition("DITERIMA_BAIK");
    setNotes("");
    setPhoto("");
    setPhotoInfo("");
    setIsCompressing(false);
  }, [isOpen, request?.id]);

  if (!isOpen || !request) return null;

  const isAdmin = currentUser.activeRole === "ADMIN";
  const isOwnRequest = String(request.requesterNrk || "").trim() === currentUser.nrk;

  const handleFile = async (file?: File) => {
    if (!file || isSubmitting || isCompressing) return;
    setIsCompressing(true);
    setPhotoInfo("Mengompres foto...");
    try {
      const result = await compressImageFile(file);
      setPhoto(result.dataUrl);
      setPhotoInfo(`${formatFileSize(result.originalBytes)} → ${formatFileSize(result.compressedBytes)} · ${result.width}×${result.height}px`);
    } catch (error: any) {
      alert(error?.message || "Gagal memproses foto.");
      setPhotoInfo("");
    } finally {
      setIsCompressing(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (isSubmitting || isCompressing) return;
    if (condition === "DITERIMA_DENGAN_CATATAN" && !notes.trim()) {
      alert("Isi catatan jika barang diterima dengan catatan.");
      return;
    }
    const success = await onConfirm(request.id, condition, notes.trim(), photo);
    if (success) onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/55 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full overflow-hidden animate-scale-up">
        <div className={`flex items-center justify-between px-6 py-4 border-b ${isAdmin ? "bg-violet-50 border-violet-100" : "bg-emerald-50 border-emerald-100"}`}>
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl bg-white border ${isAdmin ? "text-violet-600 border-violet-100" : "text-emerald-600 border-emerald-100"}`}>{isAdmin ? <ShieldCheck className="w-5 h-5" /> : <PackageCheck className="w-5 h-5" />}</div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Konfirmasi Penerimaan</h3>
              <p className="text-[10px] text-slate-500">{request.id} · {request.itemName}</p>
            </div>
          </div>
          <button type="button" disabled={isSubmitting} onClick={onClose} className="p-1.5 rounded-lg hover:bg-white text-slate-500 disabled:opacity-40"><X className="w-4 h-4" /></button>
        </div>

        <form onSubmit={submit} className="p-6 space-y-4">
          {isAdmin && (
            <div className="rounded-xl bg-violet-50 border border-violet-100 p-3 text-xs text-violet-800 flex gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <p>Anda mengonfirmasi sebagai <strong>Administrator</strong>{isOwnRequest ? " untuk permintaan sendiri" : ` atas nama ${request.requesterName}`}. Tindakan ini otomatis dicatat di tab <strong>Audit_Log</strong>.</p>
            </div>
          )}

          <div className="rounded-xl bg-slate-50 border border-slate-100 p-3 text-xs text-slate-600">
            Barang <strong>{request.quantity} {request.unit} {request.itemName}</strong> telah diserahkan dan dapat langsung dikonfirmasi.
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700">Kondisi saat diterima</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button type="button" disabled={isSubmitting} onClick={() => setCondition("DITERIMA_BAIK")} className={`p-3 rounded-xl border text-left ${condition === "DITERIMA_BAIK" ? "border-emerald-400 bg-emerald-50" : "border-slate-200 bg-white"}`}>
                <span className="text-xs font-bold text-emerald-700 flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> Diterima Baik</span>
                <p className="text-[10px] text-slate-500 mt-1">Tidak ada kendala.</p>
              </button>
              <button type="button" disabled={isSubmitting} onClick={() => setCondition("DITERIMA_DENGAN_CATATAN")} className={`p-3 rounded-xl border text-left ${condition === "DITERIMA_DENGAN_CATATAN" ? "border-amber-400 bg-amber-50" : "border-slate-200 bg-white"}`}>
                <span className="text-xs font-bold text-amber-700 flex items-center gap-1"><MessageSquare className="w-4 h-4" /> Dengan Catatan</span>
                <p className="text-[10px] text-slate-500 mt-1">Ada kondisi yang perlu dicatat.</p>
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Catatan {condition === "DITERIMA_DENGAN_CATATAN" ? <span className="text-rose-500">*</span> : <span className="font-normal text-slate-400">(opsional)</span>}</label>
            <textarea value={notes} disabled={isSubmitting} onChange={(event) => setNotes(event.target.value)} rows={3} placeholder={isAdmin ? "Catatan konfirmasi Administrator (opsional jika diterima baik)..." : condition === "DITERIMA_DENGAN_CATATAN" ? "Jelaskan kondisi atau kendala..." : "Tambahkan catatan bila diperlukan..."} className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs resize-none disabled:opacity-60" />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Foto pendukung <span className="font-normal text-slate-400">(opsional)</span></label>
            {photo ? (
              <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50">
                <img src={photo} alt="Foto konfirmasi penerimaan" className="w-full h-40 object-cover" />
                <button type="button" disabled={isSubmitting} onClick={() => { setPhoto(""); setPhotoInfo(""); }} className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-900/70 text-white disabled:opacity-40"><X className="w-3.5 h-3.5" /></button>
              </div>
            ) : (
              <button type="button" disabled={isSubmitting || isCompressing} onClick={() => fileInputRef.current?.click()} className="w-full p-4 rounded-xl border-2 border-dashed border-slate-200 hover:border-emerald-400 bg-slate-50 text-xs text-slate-600 flex flex-col items-center gap-1.5 disabled:cursor-wait">
                {isCompressing ? <ImageDown className="w-6 h-6 text-emerald-500 animate-pulse" /> : <Upload className="w-6 h-6 text-slate-400" />}
                <span className="font-semibold">{isCompressing ? "Mengompres foto..." : "Lampirkan foto jika ada kendala atau bukti tambahan"}</span>
                <span className="text-[10px] text-slate-400">JPG/PNG · maksimal 12 MB sebelum kompresi</span>
              </button>
            )}
            {photoInfo && <p className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1"><ImageDown className="w-3 h-3" /> {photoInfo}</p>}
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(event) => void handleFile(event.target.files?.[0])} />
          </div>

          <div className="rounded-xl bg-blue-50 border border-blue-100 p-3 flex gap-2 text-[10px] text-blue-800">
            <FileImage className="w-4 h-4 shrink-0" />
            <p>Setelah dikirim, status permintaan menjadi <strong>Selesai</strong>. Foto tetap opsional.</p>
          </div>

          <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
            <button type="button" disabled={isSubmitting} onClick={onClose} className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 disabled:opacity-40">Batal</button>
            <button type="submit" disabled={isSubmitting || isCompressing} className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white text-xs font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" /> {isSubmitting ? "Memproses..." : "Konfirmasi Diterima"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
