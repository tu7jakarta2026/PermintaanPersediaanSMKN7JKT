import React, { useState } from "react";
import { KeyRound, ShieldAlert } from "lucide-react";
import { AuthUser, changePin } from "../lib/auth";

interface Props {
  user: AuthUser;
  forced?: boolean;
  onChanged: (user: AuthUser) => void;
  onCancel?: () => void;
}

export default function ChangePinPanel({ user, forced = false, onChanged, onCancel }: Props) {
  const [oldPin, setOldPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");
    if (!/^\d{6}$/.test(oldPin) || !/^\d{6}$/.test(newPin)) return setError("PIN harus 6 digit angka.");
    if (newPin !== confirmPin) return setError("Konfirmasi PIN baru tidak sama.");
    if (oldPin === newPin) return setError("PIN baru harus berbeda dari PIN lama.");
    setLoading(true);
    try {
      const updated = await changePin(oldPin, newPin);
      onChanged(updated);
    } catch (err: any) {
      setError(err?.message || "Gagal mengubah PIN.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={forced ? "min-h-screen bg-slate-950 flex items-center justify-center p-5" : "fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4"}>
      <form onSubmit={submit} className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-7 space-y-5">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600"><ShieldAlert className="w-5 h-5" /></div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">{forced ? "Ganti PIN Awal" : "Ubah PIN Akun"}</h2>
            <p className="text-xs text-slate-500 mt-1">Akun {user.name} · NRK {user.nrk}</p>
          </div>
        </div>
        {forced && <div className="rounded-xl bg-amber-50 border border-amber-100 p-3 text-xs font-semibold text-amber-800">Demi keamanan, PIN awal wajib diganti sebelum dashboard dapat digunakan.</div>}
        {[{label:"PIN Lama",value:oldPin,set:setOldPin},{label:"PIN Baru",value:newPin,set:setNewPin},{label:"Konfirmasi PIN Baru",value:confirmPin,set:setConfirmPin}].map((field) => (
          <div className="space-y-1.5" key={field.label}>
            <label className="text-xs font-bold text-slate-600">{field.label}</label>
            <input type="password" inputMode="numeric" maxLength={6} value={field.value} onChange={(e) => field.set(e.target.value.replace(/\D/g, "").slice(0, 6))} className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 tracking-[0.35em] focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="••••••" />
          </div>
        ))}
        {error && <div className="rounded-xl bg-rose-50 border border-rose-100 p-3 text-xs font-semibold text-rose-700">{error}</div>}
        <div className="flex gap-2">
          {!forced && onCancel && <button type="button" onClick={onCancel} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600">Batal</button>}
          <button disabled={loading} className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white text-sm font-bold flex items-center justify-center gap-2"><KeyRound className="w-4 h-4" />{loading ? "Menyimpan..." : "Simpan PIN Baru"}</button>
        </div>
      </form>
    </div>
  );
}
