import React, { useState } from "react";
import { RequestStatus, InventoryRequest } from "../types";
import {
  X,
  Calendar,
  ShoppingBag,
  Info,
  FileImage,
  ShieldCheck,
  Clock,
  ExternalLink,
  CheckCircle2,
  UserCheck,
} from "lucide-react";
import { AuthUser } from "../lib/auth";
import { getDriveThumbnailUrl, getDriveViewUrl } from "../lib/drive";

interface RequestDetailModalProps {
  request: InventoryRequest | null;
  isOpen: boolean;
  onClose: () => void;
  requestNumber?: number;
  currentEmployee?: AuthUser | null;
}

const STATUS_BADGE: Record<RequestStatus, { text: string; bg: string }> = {
  [RequestStatus.PENDING_RECEIPT]: { text: "Menunggu Pemeriksaan Gudang", bg: "bg-blue-50 text-blue-700 border-blue-100" },
  [RequestStatus.PENDING_APPROVAL]: { text: "Menunggu Persetujuan", bg: "bg-purple-50 text-purple-700 border-purple-100" },
  [RequestStatus.PENDING_VALIDATION]: { text: "Menunggu Penyerahan Gudang", bg: "bg-amber-50 text-amber-700 border-amber-100" },
  [RequestStatus.AWAITING_REQUESTER_CONFIRMATION]: { text: "Menunggu Konfirmasi Pemohon", bg: "bg-cyan-50 text-cyan-700 border-cyan-100" },
  [RequestStatus.VALIDATED]: { text: "Selesai / Diterima", bg: "bg-emerald-50 text-emerald-700 border-emerald-100" },
  [RequestStatus.REJECTED]: { text: "Ditolak", bg: "bg-rose-50 text-rose-700 border-rose-100" },
};

function PhotoCard({ title, url, caption, date }: { title: string; url: string; caption: string; date?: string }) {
  const [imageFailed, setImageFailed] = useState(false);
  const thumbnailUrl = getDriveThumbnailUrl(url);
  const viewUrl = getDriveViewUrl(url);

  return (
    <div className="space-y-2">
      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
        <FileImage className="w-3.5 h-3.5" /> {title}
      </h4>
      <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs bg-slate-50 relative group min-h-36">
        {!imageFailed ? (
          <img
            src={thumbnailUrl}
            alt={title}
            onError={() => setImageFailed(true)}
            className="w-full h-48 object-cover object-center group-hover:scale-[1.01] transition-transform duration-300"
          />
        ) : (
          <div className="h-48 flex flex-col items-center justify-center gap-2 text-center p-5">
            <FileImage className="w-8 h-8 text-slate-300" />
            <p className="text-xs font-semibold text-slate-500">Thumbnail tidak dapat dimuat.</p>
            <p className="text-[10px] text-slate-400">Foto tetap dapat dibuka melalui Google Drive.</p>
          </div>
        )}
        <div className="absolute bottom-2 left-2 right-2 bg-slate-900/75 backdrop-blur-xs text-white p-2 rounded-lg text-[10px] flex items-center justify-between gap-2">
          <span className="flex items-center gap-1 min-w-0"><ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" /><span className="truncate">{caption}</span></span>
          {date && <span className="shrink-0">{date}</span>}
        </div>
      </div>
      <a href={viewUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-600 hover:text-blue-700">
        <ExternalLink className="w-3 h-3" /> Buka foto di Google Drive
      </a>
    </div>
  );
}

export default function RequestDetailModal({ request, isOpen, onClose, requestNumber }: RequestDetailModalProps) {
  if (!isOpen || !request) return null;

  const badge = STATUS_BADGE[request.status];
  const handoverPhotoUrl = request.handoverPhotoUrl || request.photoUrl || "";
  const steps = [
    {
      label: "Diajukan Pemohon",
      name: request.requesterName,
      date: request.requestDate,
      isDone: true,
      color: "border-indigo-500 bg-indigo-500",
    },
    {
      label: "Diperiksa Petugas Gudang",
      name: request.receivedBy,
      date: request.receivedDate,
      isDone: Boolean(request.receivedBy),
      color: "border-blue-500 bg-blue-500",
    },
    {
      label: "Disetujui Approver",
      name: request.approvedBy,
      date: request.approvedDate,
      isDone: Boolean(request.approvedBy) && request.status !== RequestStatus.REJECTED,
      color: "border-violet-500 bg-violet-500",
    },
    {
      label: "Diserahkan Petugas Gudang",
      name: request.validatedBy,
      date: request.validatedDate,
      isDone: Boolean(request.validatedBy),
      color: "border-amber-500 bg-amber-500",
    },
    {
      label: "Dikonfirmasi Pemohon",
      name: request.requesterConfirmedBy,
      date: request.requesterConfirmedDate,
      isDone: Boolean(request.requesterConfirmedBy),
      color: "border-emerald-500 bg-emerald-500",
    },
  ];

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-scale-up">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-100 sticky top-0 z-10">
          <div className="flex items-center gap-2 flex-wrap">
            {requestNumber && <span className="text-xs font-bold text-white bg-blue-600 px-2 py-0.5 rounded shadow-xs">No. {requestNumber}</span>}
            <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">{request.id}</span>
            <h3 className="text-base font-semibold text-slate-800">Rincian Pengajuan Barang</h3>
          </div>
          <button onClick={onClose} className="p-1 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-lg"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Status Permintaan</span>
              <div><span className={`px-2.5 py-0.5 text-xs font-semibold rounded-full border ${badge.bg}`}>{badge.text}</span></div>
            </div>
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Tanggal Pengajuan</span>
              <span className="text-xs font-semibold text-slate-700 flex items-center justify-end gap-1 mt-0.5"><Calendar className="w-3.5 h-3.5 text-slate-400" />{request.requestDate}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5"><ShoppingBag className="w-3.5 h-3.5" />Detail Barang & Pemohon</h4>
              <div className="space-y-3 bg-slate-50/50 p-4 rounded-xl border border-slate-100/60">
                <div><span className="text-[10px] text-slate-400 block">Nama Barang</span><span className="text-sm font-semibold text-slate-800">{request.itemName}</span></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><span className="text-[10px] text-slate-400 block">Jumlah Kebutuhan</span><span className="text-sm font-bold text-slate-800">{request.quantity} <span className="text-xs font-medium text-slate-500">{request.unit}</span></span></div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Nama Pemohon</span>
                    <span className="text-xs font-semibold text-slate-800 block">{request.requesterName}</span>
                    {request.requesterNrk && <span className="inline-block mt-0.5 text-[9px] font-mono font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">NRK: {request.requesterNrk}</span>}
                  </div>
                </div>
                <div><span className="text-[10px] text-slate-400 block">Jabatan / Unit</span><span className="text-xs font-medium text-slate-600 block">{request.requesterRole}</span></div>
                <div><span className="text-[10px] text-slate-400 block">Alasan / Keperluan</span><p className="text-xs text-slate-600 leading-relaxed mt-0.5 italic">“{request.purpose}”</p></div>
                {request.notes && <div className="p-3 bg-amber-50/50 border border-amber-100 rounded-lg"><span className="text-[10px] text-amber-700 font-bold flex items-center gap-1"><Info className="w-3 h-3" />Catatan Tindakan</span><p className="text-xs text-amber-900 mt-1">{request.notes}</p></div>}
              </div>

              {request.requestPhotoUrl && <PhotoCard title="Foto Pendukung Permintaan (Pemohon)" url={request.requestPhotoUrl} caption="Dilampirkan saat pengajuan" date={request.requestDate} />}
              {handoverPhotoUrl && <PhotoCard title="Bukti Penyerahan Barang (Gudang)" url={handoverPhotoUrl} caption={`Diserahkan oleh ${request.validatedBy || "Petugas Gudang"}`} date={request.validatedDate} />}
              {request.receiptPhotoUrl && <PhotoCard title="Foto Konfirmasi Penerimaan (Pemohon)" url={request.receiptPhotoUrl} caption={request.receiptCondition === "DITERIMA_DENGAN_CATATAN" ? "Diterima dengan catatan" : "Diterima dengan baik"} date={request.requesterConfirmedDate} />}

              {request.requesterConfirmedBy && (
                <div className={`p-4 rounded-xl border ${request.receiptCondition === "DITERIMA_DENGAN_CATATAN" ? "bg-amber-50 border-amber-100" : "bg-emerald-50 border-emerald-100"}`}>
                  <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-emerald-600" />Konfirmasi Pemohon</h4>
                  <p className="text-xs text-slate-600 mt-2">{request.requesterConfirmedBy} mengonfirmasi barang <strong>{request.receiptCondition === "DITERIMA_DENGAN_CATATAN" ? "diterima dengan catatan" : "diterima dengan baik"}</strong>.</p>
                  {request.receiptNotes && <p className="text-xs text-slate-700 mt-2 italic">“{request.receiptNotes}”</p>}
                </div>
              )}
            </div>

            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />Riwayat Proses Bertahap</h4>
              <div className="relative pl-6 space-y-6">
                <div className="absolute top-2 bottom-2 left-2.5 w-0.5 bg-slate-100" />
                {steps.map((step) => (
                  <div key={step.label} className="relative flex items-start gap-4">
                    <div className={`absolute -left-[20px] w-4.5 h-4.5 rounded-full border-2 z-10 flex items-center justify-center ${step.isDone ? step.color : "border-slate-200 bg-white"}`}>
                      {step.isDone && <span className="w-1.5 h-1.5 bg-white rounded-full" />}
                    </div>
                    <div className="space-y-1 flex-1">
                      <h5 className={`text-xs font-bold leading-none ${step.isDone ? "text-slate-800" : "text-slate-400"}`}>{step.label}</h5>
                      {step.isDone ? (
                        <div className="text-[11px] text-slate-500">
                          <p className="font-semibold flex items-center gap-1"><UserCheck className="w-3 h-3" />{step.name || "Sistem Otomatis"}</p>
                          <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5"><Calendar className="w-3 h-3" />{step.date || "Selesai"}</p>
                        </div>
                      ) : <p className="text-[10px] text-slate-300">Belum diproses</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100"><button onClick={onClose} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg">Tutup Rincian</button></div>
        </div>
      </div>
    </div>
  );
}
