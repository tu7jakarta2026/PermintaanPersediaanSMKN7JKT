import React, { useEffect, useMemo, useRef, useState } from "react";
import { InventoryRequest } from "./types";
import DashboardStats from "./components/DashboardStats";
import DashboardChart from "./components/DashboardChart";
import DashboardBarChart from "./components/DashboardBarChart";
import RequestList from "./components/RequestList";
import RequestForm from "./components/RequestForm";
import RequestDetailModal from "./components/RequestDetailModal";
import ValidateModal from "./components/ValidateModal";
import NrkLogin from "./components/NrkLogin";
import ChangePinPanel from "./components/ChangePinPanel";
import RoleSwitcher from "./components/RoleSwitcher";
import ConfirmReceiptModal from "./components/ConfirmReceiptModal";
import ProcessingOverlay, { ProcessingState } from "./components/ProcessingOverlay";
import { AppRole, AuthUser, getCurrentUser, logout, ROLE_LABELS, switchRole } from "./lib/auth";
import {
  AlertTriangle,
  Calendar,
  FileSpreadsheet,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Package,
  Plus,
  RefreshCw,
  ShieldCheck,
  UserRound,
} from "lucide-react";

const ROLE_DESCRIPTIONS = {
  PEMOHON: "Ajukan kebutuhan barang, pantau status, dan konfirmasi penerimaan secara langsung.",
  PETUGAS_GUDANG: "Periksa permintaan masuk, teruskan ke approver, lalu serahkan barang dengan bukti foto.",
  APPROVER: "Tinjau permintaan yang sudah diperiksa gudang, lalu setujui atau tolak.",
  ADMIN: "Super Admin: membuat permintaan dan menjalankan seluruh tahapan dengan audit otomatis.",
} as const;

const HIDDEN_PROCESSING: ProcessingState = {
  visible: false,
  title: "Memproses Data",
  message: "Menyiapkan proses...",
  progress: 10,
};

const sleep = (milliseconds: number) => new Promise((resolve) => setTimeout(resolve, milliseconds));

export default function App() {
  const [authLoading, setAuthLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [requests, setRequests] = useState<InventoryRequest[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [processing, setProcessing] = useState<ProcessingState>(HIDDEN_PROCESSING);
  const [errorAlert, setErrorAlert] = useState<string | null>(null);
  const [successAlert, setSuccessAlert] = useState<string | null>(null);
  const [showChangePin, setShowChangePin] = useState(false);

  const [activeRequest, setActiveRequest] = useState<InventoryRequest | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [validateTarget, setValidateTarget] = useState<InventoryRequest | null>(null);
  const [isValidateOpen, setIsValidateOpen] = useState(false);
  const [receiptTarget, setReceiptTarget] = useState<InventoryRequest | null>(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);
  const operationLockRef = useRef(false);

  const role = currentUser?.activeRole || currentUser?.appRole || "PEMOHON";
  const canCreate = role === "PEMOHON" || role === "ADMIN";

  const roleQueueCount = useMemo(() => {
    if (role === "PETUGAS_GUDANG") {
      return requests.filter((request) => ["PENDING_RECEIPT", "PENDING_VALIDATION"].includes(request.status)).length;
    }
    if (role === "APPROVER") {
      return requests.filter((request) => request.status === "PENDING_APPROVAL").length;
    }
    if (role === "PEMOHON") {
      return requests.filter((request) => request.status === "AWAITING_REQUESTER_CONFIRMATION").length;
    }
    return requests.filter((request) => !["VALIDATED", "REJECTED"].includes(request.status)).length;
  }, [requests, role]);

  useEffect(() => {
    getCurrentUser()
      .then(setCurrentUser)
      .catch((error) => setErrorAlert(error?.message || "Gagal memeriksa sesi."))
      .finally(() => setAuthLoading(false));
  }, []);

  useEffect(() => {
    if (currentUser && !currentUser.mustChangePin) void refreshRequests(false);
  }, [currentUser?.nrk, currentUser?.activeRole, currentUser?.mustChangePin]);

  const triggerAlert = (type: "success" | "error", message: string) => {
    if (type === "success") {
      setSuccessAlert(message);
      window.setTimeout(() => setSuccessAlert(null), 5000);
    } else {
      setErrorAlert(message);
    }
  };

  const handleUnauthorized = async () => {
    setCurrentUser(null);
    setRequests([]);
    try { await logout(); } catch { /* cookie may already be invalid */ }
  };

  const loadRequests = async () => {
    const response = await fetch("/api/requests", { credentials: "include" });
    const result = await response.json().catch(() => ({}));
    if (response.status === 401) {
      await handleUnauthorized();
      throw new Error("Sesi berakhir. Silakan login kembali.");
    }
    if (!response.ok || !result.success) throw new Error(result.error || `HTTP ${response.status}`);
    setRequests(Array.isArray(result.data) ? result.data : []);
  };

  const runOperation = async (
    title: string,
    initialMessage: string,
    task: (update: (message: string, progress?: number, detail?: string) => void) => Promise<void>,
  ): Promise<boolean> => {
    if (operationLockRef.current) return false;
    operationLockRef.current = true;
    setIsLoading(true);
    setErrorAlert(null);
    setProcessing({ visible: true, title, message: initialMessage, progress: 15 });
    let success = false;

    const update = (message: string, progress = 55, detail?: string) => {
      setProcessing({ visible: true, title, message, progress, detail });
    };

    try {
      await task(update);
      success = true;
      setProcessing({ visible: true, title: "Proses Berhasil", message: "Data sudah tersimpan dan dashboard telah diperbarui.", progress: 100, detail: "Anda dapat melanjutkan pekerjaan berikutnya." });
      await sleep(450);
      return true;
    } catch (error: any) {
      triggerAlert("error", error?.message || "Proses gagal. Silakan coba kembali.");
      return false;
    } finally {
      setProcessing(HIDDEN_PROCESSING);
      setIsLoading(false);
      operationLockRef.current = false;
      if (!success) await sleep(0);
    }
  };

  const refreshRequests = async (showOverlay = true): Promise<boolean> => {
    if (!currentUser) return false;
    if (showOverlay) {
      return runOperation("Memuat Data Terbaru", "Mengambil data dari Google Sheets...", async (update) => {
        await loadRequests();
        update("Menyusun ulang daftar permintaan...", 85);
      });
    }

    setIsLoading(true);
    setErrorAlert(null);
    try {
      await loadRequests();
      return true;
    } catch (error: any) {
      setErrorAlert(`Gagal memuat permintaan: ${error?.message || "Masalah jaringan"}`);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const postRequest = async (body: Record<string, unknown>) => {
    const response = await fetch("/api/requests", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const result = await response.json().catch(() => ({}));
    if (response.status === 401) {
      await handleUnauthorized();
      throw new Error("Sesi berakhir. Silakan login kembali.");
    }
    if (!response.ok || !result.success) throw new Error(result.error || `HTTP ${response.status}`);
    return result;
  };

  const handleAddRequest = async (newRequest: InventoryRequest | InventoryRequest[]): Promise<boolean> => {
    const list = Array.isArray(newRequest) ? newRequest : [newRequest];
    const hasPhoto = list.some((request) => Boolean(request.requestPhotoUrl));
    const success = await runOperation(
      "Mengirim Permintaan",
      hasPhoto ? "Mengunggah foto pendukung dan menyimpan permintaan..." : "Menyimpan permintaan ke Google Sheets...",
      async (update) => {
        for (let index = 0; index < list.length; index += 1) {
          update(`Menyimpan barang ${index + 1} dari ${list.length}...`, 25 + Math.round(((index + 1) / list.length) * 45));
          await postRequest({ action: "create", data: list[index] });
        }
        update("Memuat ulang data terbaru...", 85);
        await loadRequests();
      },
    );
    if (success) triggerAlert("success", `${list.length} permintaan berhasil dikirim.`);
    return success;
  };

  const handleWorkflowAction = async (
    id: string,
    actionType: "receive" | "approve" | "reject",
    _operatorName: string,
    notes: string,
  ): Promise<boolean> => {
    const labels = {
      receive: ["Memeriksa Permintaan", "Meneruskan permintaan ke Approver..."],
      approve: ["Menyetujui Permintaan", "Mencatat persetujuan ke Google Sheets..."],
      reject: ["Menolak Permintaan", "Mencatat keputusan penolakan..."],
    } as const;
    const [title, message] = labels[actionType];
    const success = await runOperation(title, message, async (update) => {
      await postRequest({ action: "workflow", id, workflowAction: actionType, notes });
      update("Tindakan tersimpan. Memperbarui dashboard...", 82);
      await loadRequests();
    });
    if (success) triggerAlert("success", `Tindakan untuk ${id} berhasil disimpan.`);
    return success;
  };

  const handlePhotoValidation = async (
    id: string,
    _validatorName: string,
    photoBase64: string,
    notes: string,
  ): Promise<boolean> => {
    const success = await runOperation("Menyimpan Penyerahan", "Mengunggah foto bukti penyerahan ke Google Drive...", async (update) => {
      await postRequest({ action: "workflow", id, workflowAction: "handover", photoUrl: photoBase64, notes });
      update("Foto tersimpan. Memperbarui status permintaan...", 82);
      await loadRequests();
    });
    if (success) {
      triggerAlert("success", `Penyerahan ${id} tersimpan. Menunggu konfirmasi Pemohon.`);
      setValidateTarget(null);
    }
    return success;
  };

  const handleRoleSwitch = async (nextRole: AppRole) => {
    if (!currentUser || nextRole === role) return;
    const success = await runOperation("Mengganti Mode Kerja", `Mengaktifkan dashboard ${ROLE_LABELS[nextRole]}...`, async (update) => {
      const updated = await switchRole(nextRole);
      setCurrentUser(updated);
      setActiveRequest(null);
      setIsDetailOpen(false);
      update("Role aktif diperbarui. Memuat antrean baru...", 80);
    });
    if (success) triggerAlert("success", `Mode kerja diubah ke ${ROLE_LABELS[nextRole]}.`);
  };

  const handleConfirmReceipt = async (
    id: string,
    receiptCondition: "DITERIMA_BAIK" | "DITERIMA_DENGAN_CATATAN",
    notes: string,
    photoBase64: string,
  ): Promise<boolean> => {
    const success = await runOperation("Mengonfirmasi Penerimaan", photoBase64 ? "Mengunggah foto dan menyimpan konfirmasi..." : "Menyimpan konfirmasi penerimaan...", async (update) => {
      await postRequest({ action: "workflow", id, workflowAction: "confirm_receipt", receiptCondition, notes, photoUrl: photoBase64 });
      update("Konfirmasi tersimpan. Menyelesaikan permintaan...", 85);
      await loadRequests();
    });
    if (success) {
      triggerAlert("success", `Penerimaan ${id} berhasil dikonfirmasi.`);
      setReceiptTarget(null);
    }
    return success;
  };

  const handleLogout = async () => {
    if (isLoading) return;
    try { await logout(); } finally {
      setCurrentUser(null);
      setRequests([]);
      setShowChangePin(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white gap-3">
        <RefreshCw className="w-8 h-8 animate-spin text-blue-500" />
        <p className="text-sm font-semibold text-slate-300">Memeriksa sesi aman...</p>
      </div>
    );
  }

  if (!currentUser) return <NrkLogin onLogin={setCurrentUser} />;

  if (currentUser.mustChangePin) {
    return <ChangePinPanel user={currentUser} forced onChanged={(user) => { setCurrentUser(user); triggerAlert("success", "PIN berhasil diubah."); }} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col">
      <ProcessingOverlay state={processing} />

      <header className="bg-slate-950 text-white border-b border-slate-800 sticky top-0 z-30">
        <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-blue-600 shadow-lg shadow-blue-950/40"><Package className="w-5 h-5" /></div>
            <div className="min-w-0">
              <h1 className="font-bold text-sm sm:text-base truncate">Permintaan Barang Persediaan</h1>
              <p className="text-[10px] text-slate-400 truncate">SMKN 7 Jakarta · Dashboard {ROLE_LABELS[role]}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <RoleSwitcher user={currentUser} disabled={isLoading} onChange={handleRoleSwitch} />
            <button disabled={isLoading} onClick={() => setShowChangePin(true)} className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold disabled:opacity-40"><KeyRound className="w-3.5 h-3.5" /> Ubah PIN</button>
            <button disabled={isLoading} onClick={handleLogout} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 hover:bg-rose-950 border border-slate-700 hover:border-rose-900 text-xs font-semibold disabled:opacity-40"><LogOut className="w-3.5 h-3.5" /> Keluar</button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6 flex-1">
        <section className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-2xl ${role === "ADMIN" ? "bg-violet-50 text-violet-600" : "bg-blue-50 text-blue-600"}`}><LayoutDashboard className="w-6 h-6" /></div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-xl font-bold text-slate-900">Dashboard {ROLE_LABELS[role]}</h2>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 text-[10px] font-bold flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Sesi Terverifikasi</span>
                  {role === "ADMIN" && <span className="px-2.5 py-1 rounded-full bg-violet-50 text-violet-700 border border-violet-100 text-[10px] font-bold">Super Role</span>}
                </div>
                <p className="text-sm text-slate-500 mt-1 max-w-2xl">{ROLE_DESCRIPTIONS[role]}</p>
                <div className="flex flex-wrap gap-3 mt-3 text-xs text-slate-600">
                  <span className="flex items-center gap-1.5"><UserRound className="w-3.5 h-3.5 text-slate-400" /> {currentUser.name}</span>
                  <span className="font-mono bg-slate-100 rounded px-2 py-0.5">NRK {currentUser.nrk}</span>
                  <span>{currentUser.jobTitle}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-slate-50 border border-slate-200 px-4 py-3 min-w-[150px]"><span className="text-[9px] uppercase tracking-wider font-bold text-slate-400">Antrean Role Anda</span><p className="text-2xl font-bold text-slate-900 mt-0.5">{roleQueueCount}</p></div>
              {canCreate && <button disabled={isLoading} onClick={() => setIsCreateOpen(true)} className="px-4 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-blue-100"><Plus className="w-4 h-4" /> Buat Permintaan</button>}
            </div>
          </div>
        </section>

        {successAlert && <div className="rounded-2xl bg-emerald-50 border border-emerald-100 p-4 text-xs font-semibold text-emerald-800">{successAlert}</div>}
        {errorAlert && <div className="rounded-2xl bg-rose-50 border border-rose-100 p-4 text-xs font-semibold text-rose-800 flex items-start justify-between gap-3"><span className="flex items-start gap-2"><AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />{errorAlert}</span><button onClick={() => setErrorAlert(null)} className="text-rose-500">Tutup</button></div>}

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3"><div className="p-2 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100"><FileSpreadsheet className="w-5 h-5" /></div><div><span className="text-[9px] uppercase tracking-wider font-bold text-slate-400">Sumber Data</span><p className="text-xs font-bold text-slate-800">Google Sheets melalui API aman Vercel</p></div></div>
          <div className="flex items-center gap-3"><span className="hidden sm:flex items-center gap-1 text-[10px] text-slate-500"><Calendar className="w-3.5 h-3.5" /> {new Date().toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" })}</span><button onClick={() => void refreshRequests(true)} disabled={isLoading} className="px-3 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-bold text-slate-600 flex items-center gap-1.5 disabled:opacity-40"><RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} /> Segarkan</button></div>
        </div>

        <DashboardStats requests={requests} />
        {role !== "PEMOHON" && <div className="grid grid-cols-1 gap-6"><DashboardChart requests={requests} /><DashboardBarChart requests={requests} /></div>}

        <section className="space-y-3">
          <div><h2 className="text-lg font-bold text-slate-900">Daftar Permintaan</h2><p className="text-xs text-slate-500">Data dan tombol tindakan sudah difilter sesuai role akun.</p></div>
          <RequestList
            requests={requests}
            currentRole={role}
            disabled={isLoading}
            onViewDetails={(request) => { setActiveRequest(request); setIsDetailOpen(true); }}
            onAction={handleWorkflowAction}
            onOpenValidate={(request) => { setValidateTarget(request); setIsValidateOpen(true); }}
            onOpenConfirmReceipt={(request) => { setReceiptTarget(request); setIsReceiptOpen(true); }}
            onOpenCreate={() => setIsCreateOpen(true)}
            currentEmployee={currentUser}
          />
        </section>
      </main>

      <RequestForm isOpen={isCreateOpen} isSubmitting={isLoading} onClose={() => setIsCreateOpen(false)} onAddRequest={handleAddRequest} currentEmployee={currentUser} />
      <RequestDetailModal request={activeRequest} requestNumber={activeRequest ? requests.findIndex((request) => request.id === activeRequest.id) + 1 : undefined} isOpen={isDetailOpen} onClose={() => setIsDetailOpen(false)} currentEmployee={currentUser} />
      {validateTarget && <ValidateModal isOpen={isValidateOpen} isSubmitting={isLoading} onClose={() => { setIsValidateOpen(false); setValidateTarget(null); }} onValidate={handlePhotoValidation} requestId={validateTarget.id} itemName={validateTarget.itemName} quantity={validateTarget.quantity} unit={validateTarget.unit} currentEmployee={currentUser} />}
      <ConfirmReceiptModal isOpen={isReceiptOpen} request={receiptTarget} currentUser={currentUser} isSubmitting={isLoading} onClose={() => { setIsReceiptOpen(false); setReceiptTarget(null); }} onConfirm={handleConfirmReceipt} />
      {showChangePin && <ChangePinPanel user={currentUser} onChanged={(user) => { setCurrentUser(user); setShowChangePin(false); triggerAlert("success", "PIN berhasil diubah."); }} onCancel={() => setShowChangePin(false)} />}
    </div>
  );
}
