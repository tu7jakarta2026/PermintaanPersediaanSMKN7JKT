export enum RequestStatus {
  PENDING_RECEIPT = "PENDING_RECEIPT", // Menunggu pemeriksaan Petugas Gudang
  PENDING_APPROVAL = "PENDING_APPROVAL", // Menunggu persetujuan Approver
  PENDING_VALIDATION = "PENDING_VALIDATION", // Menunggu penyerahan barang oleh Gudang
  AWAITING_REQUESTER_CONFIRMATION = "AWAITING_REQUESTER_CONFIRMATION", // Barang diserahkan, menunggu konfirmasi Pemohon
  VALIDATED = "VALIDATED", // Selesai setelah dikonfirmasi Pemohon
  REJECTED = "REJECTED" // Ditolak oleh Approver
}

export type ReceiptCondition = "DITERIMA_BAIK" | "DITERIMA_DENGAN_CATATAN";

export interface InventoryRequest {
  id: string;
  requesterName: string;
  requesterRole: string;
  requesterNrk?: string;
  itemName: string;
  quantity: number;
  unit: string;
  purpose: string;
  requestDate: string;
  status: RequestStatus;
  notes?: string;

  // Dokumentasi bertahap
  requestPhotoUrl?: string; // Foto pendukung saat pengajuan, opsional
  handoverPhotoUrl?: string; // Foto bukti penyerahan dari Petugas Gudang, wajib
  photoUrl?: string; // Alias legacy untuk foto penyerahan
  receiptPhotoUrl?: string; // Foto pendukung konfirmasi Pemohon, opsional

  // Workflow logs
  receivedBy?: string;
  receivedDate?: string;
  approvedBy?: string;
  approvedDate?: string;
  validatedBy?: string; // Petugas Gudang yang menyerahkan barang
  validatedDate?: string;
  requesterConfirmedBy?: string;
  requesterConfirmedNrk?: string;
  requesterConfirmedDate?: string;
  receiptCondition?: ReceiptCondition;
  receiptNotes?: string;
  receiptConfirmedRole?: string;
}

export interface AppConfig {
  gasUrl: string;
  isDemoMode: boolean;
}
