export interface CompressedImageResult {
  dataUrl: string;
  originalBytes: number;
  compressedBytes: number;
  width: number;
  height: number;
}

interface CompressOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  targetBytes?: number;
  maxInputBytes?: number;
}

function readAsDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Gagal membaca hasil kompresi foto."));
    reader.onload = () => resolve(String(reader.result || ""));
    reader.readAsDataURL(blob);
  });
}

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(image);
    };
    image.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("Format gambar tidak dapat dibaca browser. Gunakan JPG atau PNG."));
    };
    image.src = objectUrl;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => blob ? resolve(blob) : reject(new Error("Gagal mengompres foto.")),
      "image/jpeg",
      quality,
    );
  });
}

export async function compressImageFile(
  file: File,
  options: CompressOptions = {},
): Promise<CompressedImageResult> {
  if (!file.type.startsWith("image/")) {
    throw new Error("Hanya berkas gambar yang diperbolehkan.");
  }

  const maxInputBytes = options.maxInputBytes ?? 12 * 1024 * 1024;
  if (file.size > maxInputBytes) {
    throw new Error("Ukuran foto terlalu besar. Maksimal 12 MB sebelum kompresi.");
  }

  const image = await loadImage(file);
  const maxWidth = options.maxWidth ?? 1280;
  const maxHeight = options.maxHeight ?? 1280;
  const scale = Math.min(1, maxWidth / image.naturalWidth, maxHeight / image.naturalHeight);
  const width = Math.max(1, Math.round(image.naturalWidth * scale));
  const height = Math.max(1, Math.round(image.naturalHeight * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Browser tidak mendukung kompresi gambar.");

  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, width, height);
  context.drawImage(image, 0, 0, width, height);

  const targetBytes = options.targetBytes ?? 900 * 1024;
  const qualities = [options.quality ?? 0.78, 0.7, 0.62, 0.54];
  let blob = await canvasToBlob(canvas, qualities[0]);

  for (let index = 1; blob.size > targetBytes && index < qualities.length; index += 1) {
    blob = await canvasToBlob(canvas, qualities[index]);
  }

  return {
    dataUrl: await readAsDataUrl(blob),
    originalBytes: file.size,
    compressedBytes: blob.size,
    width,
    height,
  };
}

export function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 KB";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
