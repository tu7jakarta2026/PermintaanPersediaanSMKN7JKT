export type AppRole = "PEMOHON" | "PETUGAS_GUDANG" | "APPROVER" | "ADMIN";

export interface AuthUser {
  nrk: string;
  name: string;
  jobTitle: string;
  appRole: AppRole; // Alias kompatibilitas untuk activeRole
  activeRole: AppRole;
  roles: AppRole[];
  mustChangePin: boolean;
}

export const ROLE_LABELS: Record<AppRole, string> = {
  PEMOHON: "Pemohon",
  PETUGAS_GUDANG: "Petugas Gudang",
  APPROVER: "Approver / Kasubag TU",
  ADMIN: "Administrator",
};

const VALID_ROLES: AppRole[] = ["PEMOHON", "PETUGAS_GUDANG", "APPROVER", "ADMIN"];

function isAppRole(value: unknown): value is AppRole {
  return VALID_ROLES.includes(String(value || "") as AppRole);
}

export function normalizeAuthUser(input: any): AuthUser {
  const legacyRole: AppRole = isAppRole(input?.appRole) ? input.appRole : "PEMOHON";
  const roles = Array.isArray(input?.roles)
    ? input.roles.filter(isAppRole)
    : [legacyRole];
  const uniqueRoles = Array.from(new Set<AppRole>(roles.length ? roles : [legacyRole]));
  const activeRole = isAppRole(input?.activeRole) && uniqueRoles.includes(input.activeRole)
    ? input.activeRole
    : uniqueRoles.includes(legacyRole)
      ? legacyRole
      : uniqueRoles[0];

  return {
    nrk: String(input?.nrk || ""),
    name: String(input?.name || ""),
    jobTitle: String(input?.jobTitle || ""),
    appRole: activeRole,
    activeRole,
    roles: uniqueRoles,
    mustChangePin: Boolean(input?.mustChangePin),
  };
}

async function jsonFetch(url: string, init: RequestInit = {}) {
  const response = await fetch(url, {
    credentials: "include",
    ...init,
    headers: {
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      ...(init.headers || {}),
    },
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.success) {
    const error: any = new Error(result.error || `HTTP ${response.status}`);
    error.status = response.status;
    error.code = result.code;
    throw error;
  }
  return result;
}

export async function login(nrk: string, pin: string): Promise<AuthUser> {
  const result = await jsonFetch("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ nrk, pin }),
  });
  return normalizeAuthUser(result.user);
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const result = await jsonFetch("/api/auth/me");
    return normalizeAuthUser(result.user);
  } catch (error: any) {
    if (error?.status === 401) return null;
    throw error;
  }
}

export async function switchRole(role: AppRole): Promise<AuthUser> {
  const result = await jsonFetch("/api/auth/switch-role", {
    method: "POST",
    body: JSON.stringify({ role }),
  });
  return normalizeAuthUser(result.user);
}

export async function logout(): Promise<void> {
  await jsonFetch("/api/auth/logout", { method: "POST" });
}

export async function changePin(oldPin: string, newPin: string): Promise<AuthUser> {
  const result = await jsonFetch("/api/auth/change-pin", {
    method: "POST",
    body: JSON.stringify({ oldPin, newPin }),
  });
  return normalizeAuthUser(result.user);
}
