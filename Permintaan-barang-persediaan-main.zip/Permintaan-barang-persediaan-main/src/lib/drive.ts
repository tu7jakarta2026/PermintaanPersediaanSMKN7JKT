export function extractDriveFileId(url: string): string {
  const value = String(url || "").trim();
  if (!value) return "";

  const patterns = [
    /\/file\/d\/([a-zA-Z0-9_-]+)/,
    /[?&]id=([a-zA-Z0-9_-]+)/,
    /\/thumbnail\?[^#]*id=([a-zA-Z0-9_-]+)/,
  ];

  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (match?.[1]) return match[1];
  }
  return "";
}

export function getDriveThumbnailUrl(url: string, width = 1600): string {
  const fileId = extractDriveFileId(url);
  return fileId
    ? `https://drive.google.com/thumbnail?id=${encodeURIComponent(fileId)}&sz=w${width}`
    : url;
}

export function getDriveViewUrl(url: string): string {
  const fileId = extractDriveFileId(url);
  return fileId
    ? `https://drive.google.com/file/d/${encodeURIComponent(fileId)}/view`
    : url;
}
