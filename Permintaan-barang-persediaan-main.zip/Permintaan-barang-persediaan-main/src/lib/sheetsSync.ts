import { INVENTORY_ITEMS, InventoryItem } from "./items";

export async function fetchLiveItems(): Promise<{ success: boolean; source: string; data: InventoryItem[]; warning?: string }> {
  try {
    const response = await fetch("/api/items", { credentials: "include" });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.error || `HTTP ${response.status}`);
    return result;
  } catch (error: any) {
    return {
      success: true,
      source: "Preloaded List (Fallback)",
      warning: error?.message || "Gagal mengambil master barang.",
      data: INVENTORY_ITEMS,
    };
  }
}

export async function postToGas(): Promise<{ success: false; error: string }> {
  return { success: false, error: "Akses langsung ke Apps Script dinonaktifkan." };
}

export async function fetchRequestsFromGas(): Promise<{ success: false; error: string }> {
  return { success: false, error: "Akses langsung ke Apps Script dinonaktifkan." };
}
