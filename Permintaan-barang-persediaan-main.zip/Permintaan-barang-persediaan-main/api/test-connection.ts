import { callGas, isRole, readSession } from "../lib/serverless/auth.js";
import { setApiHeaders } from "../lib/serverless/shared.js";

export default async function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Method not allowed." });
  const user = readSession(req);
  if (!user) return res.status(401).json({ success: false, error: "Belum login." });
  if (!isRole(user, "ADMIN")) return res.status(403).json({ success: false, error: "Hanya Admin yang dapat mengetes koneksi." });
  try {
    const result = await callGas("health");
    return res.status(200).json({ success: true, message: "Koneksi berhasil.", data: result });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error?.message || "Koneksi gagal." });
  }
}
