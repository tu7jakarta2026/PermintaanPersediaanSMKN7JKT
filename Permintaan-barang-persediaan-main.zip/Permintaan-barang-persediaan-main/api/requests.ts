import { callGas, isRole, requireSession, SessionUser } from "../lib/serverless/auth.js";
import { setApiHeaders } from "../lib/serverless/shared.js";

const ALLOWED_STATUSES = [
  "PENDING_RECEIPT",
  "PENDING_APPROVAL",
  "PENDING_VALIDATION",
  "AWAITING_REQUESTER_CONFIRMATION",
  "VALIDATED",
  "REJECTED",
];

function nowString(): string {
  return new Date().toISOString();
}

function normalizeRequest(item: any): any {
  const handoverPhotoUrl = String(item?.handoverPhotoUrl || item?.photoUrl || "");
  return {
    id: String(item?.id || ""),
    requesterName: String(item?.requesterName || ""),
    requesterRole: String(item?.requesterRole || ""),
    requesterNrk: String(item?.requesterNrk || ""),
    itemName: String(item?.itemName || ""),
    quantity: Number(item?.quantity || 0),
    unit: String(item?.unit || ""),
    purpose: String(item?.purpose || ""),
    requestDate: String(item?.requestDate || ""),
    status: ALLOWED_STATUSES.includes(String(item?.status)) ? String(item.status) : "PENDING_RECEIPT",
    notes: String(item?.notes || ""),
    requestPhotoUrl: String(item?.requestPhotoUrl || ""),
    handoverPhotoUrl,
    photoUrl: handoverPhotoUrl,
    receiptPhotoUrl: String(item?.receiptPhotoUrl || ""),
    receivedBy: String(item?.receivedBy || ""),
    receivedDate: String(item?.receivedDate || ""),
    approvedBy: String(item?.approvedBy || ""),
    approvedDate: String(item?.approvedDate || ""),
    validatedBy: String(item?.validatedBy || ""),
    validatedDate: String(item?.validatedDate || ""),
    requesterConfirmedBy: String(item?.requesterConfirmedBy || ""),
    requesterConfirmedNrk: String(item?.requesterConfirmedNrk || ""),
    requesterConfirmedDate: String(item?.requesterConfirmedDate || ""),
    receiptCondition: String(item?.receiptCondition || ""),
    receiptNotes: String(item?.receiptNotes || ""),
    receiptConfirmedRole: String(item?.receiptConfirmedRole || ""),
  };
}

async function getAllRequests(): Promise<any[]> {
  const result = await callGas("listRequests");
  return Array.isArray(result.data) ? result.data.map(normalizeRequest) : [];
}

function isAdmin(user: SessionUser): boolean {
  return (user.activeRole || user.appRole) === "ADMIN";
}

function buildAudit(
  user: SessionUser,
  requestId: string,
  action: string,
  statusBefore: string,
  statusAfter: string,
  notes: string,
  actedAs: string,
  metadata: Record<string, unknown> = {},
) {
  return {
    requestId,
    timestamp: nowString(),
    actorNrk: user.nrk,
    actorName: user.name,
    activeRole: user.activeRole || user.appRole,
    actedAs,
    action,
    statusBefore,
    statusAfter,
    notes,
    isAdminOverride: isAdmin(user),
    metadata,
  };
}

function validateImageData(value: string, label: string): string | null {
  if (value && !value.startsWith("data:image/")) {
    return `${label} tidak valid.`;
  }
  return null;
}

export default async function handler(req: any, res: any) {
  setApiHeaders(res);
  const user = requireSession(req, res);
  if (!user) return;

  try {
    if (req.method === "GET") {
      const allRequests = await getAllRequests();
      const activeRole = user.activeRole || user.appRole;
      const data = activeRole === "PEMOHON"
        ? allRequests.filter((item) => String(item.requesterNrk).trim() === user.nrk)
        : allRequests;

      return res.status(200).json({ success: true, source: "Google Sheets", data });
    }

    if (req.method !== "POST") {
      return res.status(405).json({ success: false, error: "Method not allowed." });
    }

    const action = String(req.body?.action || "");

    if (action === "create") {
      if (!isRole(user, "PEMOHON")) {
        return res.status(403).json({ success: false, error: "Akun Anda tidak memiliki akses untuk membuat permintaan." });
      }

      const input = req.body?.data || {};
      const itemName = String(input.itemName || "").trim();
      const unit = String(input.unit || "").trim();
      const purpose = String(input.purpose || "").trim();
      const quantity = Number(input.quantity || 0);
      const requestPhotoUrl = String(input.requestPhotoUrl || "");
      const imageError = validateImageData(requestPhotoUrl, "Format foto pendukung permintaan");

      if (!itemName || !unit || !purpose || !Number.isFinite(quantity) || quantity <= 0) {
        return res.status(400).json({ success: false, error: "Nama barang, jumlah, satuan, dan keperluan wajib diisi." });
      }
      if (imageError) return res.status(400).json({ success: false, error: imageError });

      const id = String(input.id || `REQ-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`);
      const data = {
        id,
        requesterName: user.name,
        requesterRole: user.jobTitle,
        requesterNrk: user.nrk,
        itemName,
        quantity,
        unit,
        purpose,
        requestDate: String(input.requestDate || new Date().toISOString().slice(0, 10)),
        status: "PENDING_RECEIPT",
        notes: "",
        requestPhotoUrl,
        handoverPhotoUrl: "",
        receiptPhotoUrl: "",
        receivedBy: "",
        receivedDate: "",
        approvedBy: "",
        approvedDate: "",
        validatedBy: "",
        validatedDate: "",
        requesterConfirmedBy: "",
        requesterConfirmedNrk: "",
        requesterConfirmedDate: "",
        receiptCondition: "",
        receiptNotes: "",
        receiptConfirmedRole: "",
      };

      const audit = buildAudit(
        user,
        id,
        "CREATE_REQUEST",
        "",
        "PENDING_RECEIPT",
        purpose,
        "PEMOHON",
        { itemName, quantity, unit },
      );
      const result = await callGas("createRequest", { data, audit });
      return res.status(200).json({ success: true, message: result.message || "Permintaan berhasil dibuat.", id });
    }

    if (action === "workflow") {
      const id = String(req.body?.id || "").trim();
      const workflowAction = String(req.body?.workflowAction || "").trim();
      const notes = String(req.body?.notes || "").trim();
      const photoUrl = String(req.body?.photoUrl || "");
      if (!id) return res.status(400).json({ success: false, error: "ID permintaan wajib dikirim." });

      const allRequests = await getAllRequests();
      const current = allRequests.find((item) => item.id === id);
      if (!current) return res.status(404).json({ success: false, error: "Permintaan tidak ditemukan." });

      const updated: any = { id };
      const timestamp = nowString();
      let auditAction = "";
      let actedAs: string = user.activeRole || user.appRole;
      let auditNotes = notes;

      if (workflowAction === "receive") {
        if (!isRole(user, "PETUGAS_GUDANG")) {
          return res.status(403).json({ success: false, error: "Aktifkan role Petugas Gudang atau gunakan akun Admin." });
        }
        if (current.status !== "PENDING_RECEIPT") {
          return res.status(409).json({ success: false, error: "Permintaan ini tidak lagi menunggu pemeriksaan gudang." });
        }
        actedAs = "PETUGAS_GUDANG";
        auditAction = "WAREHOUSE_RECEIVE";
        Object.assign(updated, {
          status: "PENDING_APPROVAL",
          receivedBy: user.name,
          receivedDate: timestamp,
          notes: notes || "Permintaan telah diperiksa Petugas Gudang dan diteruskan untuk persetujuan.",
        });
      } else if (workflowAction === "approve") {
        if (!isRole(user, "APPROVER")) {
          return res.status(403).json({ success: false, error: "Aktifkan role Approver atau gunakan akun Admin." });
        }
        if (current.status !== "PENDING_APPROVAL") {
          return res.status(409).json({ success: false, error: "Permintaan ini tidak sedang menunggu persetujuan." });
        }
        actedAs = "APPROVER";
        auditAction = "APPROVE_REQUEST";
        Object.assign(updated, {
          status: "PENDING_VALIDATION",
          approvedBy: user.name,
          approvedDate: timestamp,
          notes: notes || "Permintaan disetujui dan menunggu penyerahan barang oleh Petugas Gudang.",
        });
      } else if (workflowAction === "reject") {
        if (!isRole(user, "APPROVER")) {
          return res.status(403).json({ success: false, error: "Aktifkan role Approver atau gunakan akun Admin." });
        }
        if (current.status !== "PENDING_APPROVAL") {
          return res.status(409).json({ success: false, error: "Permintaan ini tidak sedang menunggu persetujuan." });
        }
        actedAs = "APPROVER";
        auditAction = "REJECT_REQUEST";
        Object.assign(updated, {
          status: "REJECTED",
          approvedBy: user.name,
          approvedDate: timestamp,
          notes: notes || "Permintaan ditolak.",
        });
      } else if (workflowAction === "handover" || workflowAction === "validate") {
        if (!isRole(user, "PETUGAS_GUDANG")) {
          return res.status(403).json({ success: false, error: "Aktifkan role Petugas Gudang atau gunakan akun Admin." });
        }
        if (current.status !== "PENDING_VALIDATION") {
          return res.status(409).json({ success: false, error: "Permintaan ini tidak sedang menunggu penyerahan barang." });
        }
        const imageError = validateImageData(photoUrl, "Format foto bukti penyerahan");
        if (imageError) return res.status(400).json({ success: false, error: imageError });
        if (!photoUrl && !current.handoverPhotoUrl) {
          return res.status(400).json({ success: false, error: "Foto bukti penyerahan wajib dilampirkan." });
        }
        actedAs = "PETUGAS_GUDANG";
        auditAction = "HANDOVER_REQUEST";
        Object.assign(updated, {
          status: "AWAITING_REQUESTER_CONFIRMATION",
          validatedBy: user.name,
          validatedDate: timestamp,
          handoverPhotoUrl: photoUrl || current.handoverPhotoUrl,
          notes: notes || "Barang telah diserahkan dan menunggu konfirmasi langsung dari Pemohon.",
        });
      } else if (workflowAction === "confirm_receipt") {
        const adminOverride = isAdmin(user);
        const isOriginalRequester = String(current.requesterNrk || "").trim() === user.nrk;
        if (!adminOverride && !isRole(user, "PEMOHON")) {
          return res.status(403).json({ success: false, error: "Aktifkan role Pemohon untuk mengonfirmasi penerimaan." });
        }
        if (!adminOverride && !isOriginalRequester) {
          return res.status(403).json({ success: false, error: "Hanya Pemohon asli atau Administrator yang dapat mengonfirmasi penerimaan." });
        }
        if (current.status !== "AWAITING_REQUESTER_CONFIRMATION") {
          return res.status(409).json({ success: false, error: "Permintaan ini belum siap dikonfirmasi." });
        }

        const condition = String(req.body?.receiptCondition || "DITERIMA_BAIK");
        const receiptCondition = condition === "DITERIMA_DENGAN_CATATAN"
          ? "DITERIMA_DENGAN_CATATAN"
          : "DITERIMA_BAIK";
        if (receiptCondition === "DITERIMA_DENGAN_CATATAN" && !notes) {
          return res.status(400).json({ success: false, error: "Catatan wajib diisi jika barang diterima dengan catatan." });
        }
        const imageError = validateImageData(photoUrl, "Format foto konfirmasi");
        if (imageError) return res.status(400).json({ success: false, error: imageError });

        actedAs = adminOverride ? "PEMOHON_OVERRIDE" : "PEMOHON";
        auditAction = adminOverride ? "ADMIN_CONFIRM_RECEIPT" : "CONFIRM_RECEIPT";
        auditNotes = notes || (adminOverride
          ? `Dikonfirmasi oleh Administrator atas nama Pemohon ${current.requesterName}.`
          : "Barang diterima dengan baik.");
        Object.assign(updated, {
          status: "VALIDATED",
          requesterConfirmedBy: user.name,
          requesterConfirmedNrk: user.nrk,
          requesterConfirmedDate: timestamp,
          receiptCondition,
          receiptNotes: auditNotes,
          receiptPhotoUrl: photoUrl,
          receiptConfirmedRole: user.activeRole || user.appRole,
          notes: auditNotes,
        });
      } else {
        return res.status(400).json({ success: false, error: "Aksi workflow tidak valid." });
      }

      const audit = buildAudit(
        user,
        id,
        auditAction,
        current.status,
        updated.status,
        auditNotes || updated.notes || "",
        actedAs,
        {
          requesterNrk: current.requesterNrk,
          requesterName: current.requesterName,
          itemName: current.itemName,
        },
      );
      const result = await callGas("updateRequest", { data: updated, audit });
      return res.status(200).json({ success: true, message: result.message || "Status berhasil diperbarui." });
    }

    return res.status(400).json({ success: false, error: "Action tidak valid." });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error?.message || "Gagal menghubungi Google Sheets." });
  }
}
