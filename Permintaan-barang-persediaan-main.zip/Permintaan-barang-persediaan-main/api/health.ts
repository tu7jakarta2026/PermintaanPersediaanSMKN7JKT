export default function handler(req: any, res: any) {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Content-Type", "application/json; charset=utf-8");

  if (req.method !== "GET") {
    return res.status(405).json({ success: false, error: "Method not allowed." });
  }

  return res.status(200).json({
    success: true,
    service: "permintaan-barang-api",
    gasConfigured: Boolean(process.env.GAS_URL?.trim()),
    authConfigured: Boolean(
      process.env.GAS_BACKEND_SECRET?.trim() && process.env.SESSION_SECRET?.trim()
    ),
    timestamp: new Date().toISOString(),
  });
}
