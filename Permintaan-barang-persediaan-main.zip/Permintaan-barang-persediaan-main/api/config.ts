import { readSession } from "../lib/serverless/auth.js";
import { setApiHeaders } from "../lib/serverless/shared.js";

export default function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "GET") return res.status(405).json({ success: false, error: "Method not allowed." });
  const user = readSession(req);
  if (!user) return res.status(401).json({ success: false, error: "Belum login." });
  return res.status(200).json({
    success: true,
    configured: Boolean(process.env.GAS_URL?.trim() && process.env.GAS_BACKEND_SECRET?.trim() && process.env.SESSION_SECRET?.trim()),
  });
}
