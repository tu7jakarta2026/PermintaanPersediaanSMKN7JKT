import { callGas, setSessionCookie } from "../../lib/serverless/auth.js";
import { setApiHeaders } from "../../lib/serverless/shared.js";

export default async function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Method not allowed." });

  const nrk = String(req.body?.nrk || "").trim();
  const pin = String(req.body?.pin || "").trim();
  if (!nrk || !pin) return res.status(400).json({ success: false, error: "NRK dan PIN wajib diisi." });
  if (!/^\d{4,20}$/.test(nrk)) return res.status(400).json({ success: false, error: "Format NRK tidak valid." });
  if (!/^\d{6}$/.test(pin)) return res.status(400).json({ success: false, error: "PIN harus 6 digit angka." });

  try {
    const result = await callGas("authLogin", { nrk, pin });
    setSessionCookie(res, result.user);
    return res.status(200).json({ success: true, user: result.user });
  } catch (error: any) {
    return res.status(401).json({ success: false, error: error?.message || "Login gagal." });
  }
}
