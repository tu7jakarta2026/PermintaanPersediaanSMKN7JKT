import { callGas, readSession, setSessionCookie } from "../../lib/serverless/auth.js";
import { setApiHeaders } from "../../lib/serverless/shared.js";

export default async function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Method not allowed." });
  const user = readSession(req);
  if (!user) return res.status(401).json({ success: false, error: "Sesi tidak valid atau sudah berakhir." });

  const oldPin = String(req.body?.oldPin || "").trim();
  const newPin = String(req.body?.newPin || "").trim();
  if (!/^\d{6}$/.test(oldPin) || !/^\d{6}$/.test(newPin)) {
    return res.status(400).json({ success: false, error: "PIN lama dan PIN baru harus 6 digit angka." });
  }
  if (oldPin === newPin) return res.status(400).json({ success: false, error: "PIN baru harus berbeda dari PIN lama." });

  try {
    const result = await callGas("authChangePin", { nrk: user.nrk, oldPin, newPin });
    const updatedUser = { ...user, mustChangePin: false };
    setSessionCookie(res, updatedUser);
    return res.status(200).json({ success: true, user: updatedUser, message: result.message || "PIN berhasil diubah." });
  } catch (error: any) {
    return res.status(400).json({ success: false, error: error?.message || "Gagal mengubah PIN." });
  }
}
