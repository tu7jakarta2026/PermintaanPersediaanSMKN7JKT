import { clearSessionCookie } from "../../lib/serverless/auth.js";
import { setApiHeaders } from "../../lib/serverless/shared.js";

export default function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Method not allowed." });
  clearSessionCookie(res);
  return res.status(200).json({ success: true });
}
