import { AppRole, hasAssignedRole, readSession, setSessionCookie } from "../../lib/serverless/auth.js";
import { setApiHeaders } from "../../lib/serverless/shared.js";

const VALID_ROLES: AppRole[] = ["PEMOHON", "PETUGAS_GUDANG", "APPROVER", "ADMIN"];

export default function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Method not allowed." });

  const user = readSession(req);
  if (!user) return res.status(401).json({ success: false, error: "Sesi tidak valid atau sudah berakhir." });

  const role = String(req.body?.role || "") as AppRole;
  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({ success: false, error: "Role tidak valid." });
  }
  if (!hasAssignedRole(user, role)) {
    return res.status(403).json({ success: false, error: "Role tersebut tidak diberikan kepada akun Anda." });
  }

  const updatedUser = { ...user, activeRole: role, appRole: role };
  setSessionCookie(res, updatedUser);
  return res.status(200).json({ success: true, user: updatedUser });
}
