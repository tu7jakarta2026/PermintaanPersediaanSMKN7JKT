import { INVENTORY_ITEMS } from "../src/lib/items.js";
import { readSession } from "../lib/serverless/auth.js";
import { fetchTextWithTimeout, setApiHeaders } from "../lib/serverless/shared.js";

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row = [""];
  let inQuotes = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"') {
      if (inQuotes && next === '"') { row[row.length - 1] += '"'; i += 1; }
      else inQuotes = !inQuotes;
    } else if (char === "," && !inQuotes) row.push("");
    else if ((char === "\r" || char === "\n") && !inQuotes) {
      if (char === "\r" && next === "\n") i += 1;
      if (row.some((cell) => cell.trim() !== "")) rows.push(row);
      row = [""];
    } else row[row.length - 1] += char;
  }
  if (row.some((cell) => cell.trim() !== "")) rows.push(row);
  return rows;
}

export default async function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "GET") return res.status(405).json({ success: false, error: "Method not allowed." });
  if (!readSession(req)) return res.status(401).json({ success: false, error: "Belum login." });

  const csvUrl = process.env.ITEMS_CSV_URL?.trim();
  if (!csvUrl) return res.status(200).json({ success: true, source: "Preloaded List (Fallback)", data: INVENTORY_ITEMS });

  try {
    const { response, text } = await fetchTextWithTimeout(csvUrl);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const rows = parseCsv(text);
    if (rows.length < 2) throw new Error("Data barang kosong.");
    const header = rows[0].map((value) => value.toLowerCase().trim());
    const codeIdx = header.findIndex((value) => value.includes("kode"));
    const nameIdx = header.findIndex((value) => value.includes("nama"));
    const unitIdx = header.findIndex((value) => value.includes("satuan"));
    const brandIdx = header.findIndex((value) => value.includes("merk"));
    if (nameIdx < 0) throw new Error("Kolom nama barang tidak ditemukan.");
    const itemMap = new Map<string, { name: string; code: string; unit: string; brands: Set<string> }>();
    for (const row of rows.slice(1)) {
      const name = row[nameIdx]?.trim() || "";
      if (!name) continue;
      const key = name.toLowerCase();
      if (!itemMap.has(key)) itemMap.set(key, { name, code: codeIdx >= 0 ? row[codeIdx]?.trim() || "" : "", unit: unitIdx >= 0 ? row[unitIdx]?.trim() || "" : "", brands: new Set<string>() });
      const brand = brandIdx >= 0 ? row[brandIdx]?.trim() || "" : "";
      if (brand) itemMap.get(key)?.brands.add(brand);
    }
    const data = Array.from(itemMap.values()).map((item) => ({ name: item.name, code: item.code, unit: item.unit, brands: Array.from(item.brands) })).sort((a, b) => a.name.localeCompare(b.name));
    return res.status(200).json({ success: true, source: "Google Sheets (Live)", data });
  } catch (error: any) {
    return res.status(200).json({ success: true, source: "Preloaded List (Fallback)", warning: error?.message || "Gagal membaca master barang.", data: INVENTORY_ITEMS });
  }
}
