import { callGas, isRole, readSession } from "../lib/serverless/auth.js";
import { setApiHeaders } from "../lib/serverless/shared.js";

export default async function handler(req: any, res: any) {
  setApiHeaders(res);
  if (req.method !== "GET") return res.status(405).json({ success: false, error: "Method not allowed." });
  const user = readSession(req);
  if (!user) return res.status(401).json({ success: false, error: "Belum login." });
  if (!isRole(user, "ADMIN")) return res.status(403).json({ success: false, error: "Hanya Admin yang dapat melihat master pengguna." });
  try {
    const result = await callGas("listUsers");
    return res.status(200).json({ success: true, source: "Google Sheets", data: result.data || [] });
  } catch (error: any) {
    return res.status(502).json({ success: false, error: error?.message || "Gagal membaca master pengguna." });
  }
}
